/* ==========================================================================
   DOA IBU Trading Journal — theme.js
   --------------------------------------------------------------------------
   Muat PALING AWAL di <head>, sinkron (tanpa defer/async), agar tema terpasang
   sebelum halaman pertama digambar dan tidak ada kedip terang→gelap:

       <script src="theme.js"></script>

   Aturan memilih tema (berurutan):
     1. Pilihan pengguna di localStorage  (key "themeMode": "dark" | "light")
     2. Tema sistem/OS:  OS terang → light;  OS gelap / tanpa preferensi → dark
   Selama pengguna belum memilih manual, aplikasi ikut berubah saat OS berubah.

   Yang dilakukan skrip:
     - Mengisi <html data-theme="dark|light">           (dipakai styles.css + Tailwind)
     - Menyinkronkan class `light` pada <body>           (kompatibilitas ds.css & CSS lama)
     - Memperbarui <meta name="theme-color">
     - Mengikat tombol [data-theme-toggle] atau #btn-theme-toggle (event delegation)
     - Menyinkronkan antar-tab lewat event `storage`
     - Mengirim event `themechange` di window, mis. untuk menggambar ulang Chart.js

   API global (opsional):
     DoaTheme.get()            → 'dark' | 'light'  (tema yang sedang tampil)
     DoaTheme.getPreference()  → 'dark' | 'light' | 'system'
     DoaTheme.set('light')     → paksa tema & simpan;  set('system') → hapus pilihan, ikut OS
     DoaTheme.toggle()         → ganti dark ↔ light & simpan
   ========================================================================== */
(function () {
  'use strict';

  var STORAGE_KEY   = 'themeMode';          // sama dengan key lama → pilihan pengguna lama tetap terbaca
  var DEFAULT_THEME = 'dark';
  var META_COLORS   = { dark: '#0E0F11', light: '#F4F3EF' };
  var TOGGLE_SEL    = '[data-theme-toggle], #btn-theme-toggle';

  var root = document.documentElement;
  var lightQuery = window.matchMedia ? window.matchMedia('(prefers-color-scheme: light)') : null;
  var transitionTimer = null;

  /* ---------- localStorage (aman untuk Safari private / storage diblokir) ---------- */
  function readStored() {
    try {
      var v = localStorage.getItem(STORAGE_KEY);
      return v === 'dark' || v === 'light' ? v : null;
    } catch (e) { return null; }
  }
  function writeStored(theme) {
    try {
      if (theme) localStorage.setItem(STORAGE_KEY, theme);
      else localStorage.removeItem(STORAGE_KEY);
    } catch (e) { /* abaikan: tema tetap berlaku untuk sesi ini */ }
  }

  /* ---------- Deteksi OS ---------- */
  function systemTheme() {
    return lightQuery && lightQuery.matches ? 'light' : DEFAULT_THEME;
  }
  function resolveTheme() {
    return readStored() || systemTheme();
  }

  /* ---------- Penerapan ke DOM ---------- */
  function syncBody(theme) {
    if (document.body) document.body.classList.toggle('light', theme === 'light');
  }

  function syncMeta(theme) {
    var meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute('content', META_COLORS[theme]);
  }

  function syncToggles(theme) {
    var next = theme === 'light' ? 'gelap' : 'terang';
    var label = 'Ganti ke mode ' + next;

    var buttons = document.querySelectorAll(TOGGLE_SEL);
    for (var i = 0; i < buttons.length; i++) {
      buttons[i].setAttribute('aria-label', label);
      buttons[i].setAttribute('title', label);
    }

    // Ikon: tampilkan ikon yang sesuai tema aktif (kompatibel dengan #icon-theme-dark / #icon-theme-light lama)
    var iconDark  = document.querySelectorAll('[data-theme-icon="dark"], #icon-theme-dark');
    var iconLight = document.querySelectorAll('[data-theme-icon="light"], #icon-theme-light');
    for (var d = 0; d < iconDark.length; d++)  iconDark[d].classList.toggle('hidden', theme !== 'dark');
    for (var l = 0; l < iconLight.length; l++) iconLight[l].classList.toggle('hidden', theme !== 'light');
  }

  function flashTransition() {
    if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    root.classList.add('theme-transition');
    clearTimeout(transitionTimer);
    transitionTimer = setTimeout(function () { root.classList.remove('theme-transition'); }, 300);
  }

  function apply(theme, source) {
    var changed = root.getAttribute('data-theme') !== theme;

    if (changed && source !== 'init') flashTransition();

    root.setAttribute('data-theme', theme);
    syncBody(theme);
    syncMeta(theme);
    syncToggles(theme);

    if (changed) {
      try {
        window.dispatchEvent(new CustomEvent('themechange', { detail: { theme: theme, source: source } }));
      } catch (e) { /* CustomEvent tidak didukung: abaikan */ }
    }
  }

  /* ---------- API publik ---------- */
  function set(choice) {
    if (choice === 'system') {
      writeStored(null);
      apply(systemTheme(), 'user');
    } else if (choice === 'dark' || choice === 'light') {
      writeStored(choice);
      apply(choice, 'user');
    }
  }
  function toggle() {
    set(root.getAttribute('data-theme') === 'light' ? 'dark' : 'light');
  }

  window.DoaTheme = {
    get: function () { return root.getAttribute('data-theme') || DEFAULT_THEME; },
    getPreference: function () { return readStored() || 'system'; },
    set: set,
    toggle: toggle
  };

  /* ---------- 1) Terapkan sekarang (di <head>, sebelum paint pertama) ---------- */
  apply(resolveTheme(), 'init');

  /* <body> belum ada saat skrip jalan di <head>: sinkronkan begitu elemen itu muncul */
  if (!document.body && window.MutationObserver) {
    var observer = new MutationObserver(function () {
      if (document.body) {
        observer.disconnect();
        syncBody(root.getAttribute('data-theme'));
      }
    });
    observer.observe(root, { childList: true });
  }

  /* ---------- 2) Setelah DOM siap: pastikan tombol & ikon sinkron ---------- */
  document.addEventListener('DOMContentLoaded', function () {
    var theme = root.getAttribute('data-theme');
    syncBody(theme);
    syncToggles(theme);
  });

  /* ---------- 3) Klik tombol toggle (delegation: tombol dirender belakangan pun jalan) ---------- */
  document.addEventListener('click', function (e) {
    var target = e.target;
    if (target && target.closest && target.closest(TOGGLE_SEL)) toggle();
  });

  /* ---------- 4) Ikuti perubahan tema OS — hanya jika pengguna belum memilih manual ---------- */
  function onSystemChange() {
    if (!readStored()) apply(systemTheme(), 'system');
  }
  if (lightQuery) {
    if (lightQuery.addEventListener) lightQuery.addEventListener('change', onSystemChange);
    else if (lightQuery.addListener) lightQuery.addListener(onSystemChange);   // Safari < 14
  }

  /* ---------- 5) Sinkron antar-tab ---------- */
  window.addEventListener('storage', function (e) {
    if (e.key === STORAGE_KEY || e.key === null) apply(resolveTheme(), 'storage');
  });
})();
