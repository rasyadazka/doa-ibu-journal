importScripts('./reminder-core.js');
const R = self.DoaIbuReminder;

const VERSION = 'v16-12-2';
const SHELL = `doaibu-shell-${VERSION}`;
const RUNTIME = `doaibu-runtime-${VERSION}`;
const SHELL_FILES = ['./', './index.html', './manifest.webmanifest', './reminder-core.js', './v16-stats.js', './ds.css', './styles.css', './theme.js', './tailwind.config.js', './icons/icon-192.png', './icons/icon-512.png', './icons/logo-512.png'];

// Hanya library statis (CDN) yang boleh di-cache. Firebase Auth/Firestore/imgbb TIDAK disentuh.
const CACHEABLE_HOSTS = ['cdn.tailwindcss.com', 'cdnjs.cloudflare.com', 'fonts.googleapis.com', 'fonts.gstatic.com', 'www.gstatic.com'];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(SHELL).then(c => c.addAll(SHELL_FILES)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys()
      .then(keys => Promise.all(keys.filter(k => ![SHELL, RUNTIME].includes(k)).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', e => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);

  // Halaman utama: network-first supaya update langsung muncul, fallback ke cache saat offline
  if (req.mode === 'navigate') {
    e.respondWith(
      fetch(req).then(res => {
        const copy = res.clone();
        caches.open(SHELL).then(c => c.put('./index.html', copy));
        return res;
      }).catch(() => caches.match('./index.html'))
    );
    return;
  }

  const sameOrigin = url.origin === self.location.origin;
  const cdn = CACHEABLE_HOSTS.includes(url.hostname) && !url.pathname.includes('/firebasejs/__/');
  if (!sameOrigin && !cdn) return; // biarkan Firebase, imgbb, dll lewat jaringan langsung

  // Stale-while-revalidate
  e.respondWith(
    caches.open(RUNTIME).then(async cache => {
      const cached = await cache.match(req);
      const network = fetch(req).then(res => {
        if (res && (res.ok || res.type === 'opaque')) cache.put(req, res.clone());
        return res;
      }).catch(() => cached);
      return cached || network;
    })
  );
});

// ============ PENGINGAT JOURNAL ============
// Dipicu oleh Periodic Background Sync (Chrome Android, PWA terpasang). Browser yang menentukan
// seberapa sering event ini jalan, jadi ini pelengkap — bukan jaminan tepat waktu.
async function checkReminder() {
  const s = await R.idbGet('settings');
  if (!s || !s.enabled) return;
  const dates = (await R.idbGet('journalDates')) || [];
  const log = await R.idbGet('log');
  const now = new Date();
  if (!R.shouldNotify(s, dates, log, now)) return;
  // Kalau aplikasi sedang terbuka, banner di dalam aplikasi yang menangani.
  const wins = await self.clients.matchAll({ type: 'window' });
  if (wins.some(w => w.visibilityState === 'visible')) return;
  const lang = (await R.idbGet('lang')) || 'id';
  const n = R.notificationOptions(s, lang);
  await self.registration.showNotification(n.title, n.options);
  await R.idbSet('log', R.nextLog(log, now));
}

self.addEventListener('periodicsync', e => {
  if (e.tag === 'journal-reminder') e.waitUntil(checkReminder());
});

self.addEventListener('notificationclick', e => {
  e.notification.close();
  const url = (e.notification.data && e.notification.data.url) || './?action=new-journal';
  e.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then(list => {
      for (const c of list) {
        if ('focus' in c) { c.postMessage({ type: 'reminder-open' }); return c.focus(); }
      }
      return self.clients.openWindow(url);
    })
  );
});
