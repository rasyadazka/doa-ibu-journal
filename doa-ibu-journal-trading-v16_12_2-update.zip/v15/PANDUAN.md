# Panduan Deploy: Doa Ibu Journal (PWA)

## Isi folder
- index.html — aplikasi (sudah ditambah manifest, service worker, tombol install)
- manifest.webmanifest — identitas aplikasi
- sw.js — service worker (cache & mode offline sebagian)
- icons/ — ikon aplikasi (ganti dengan logo asli, ukuran sama)
- _headers — pengaturan cache untuk Netlify

## Langkah
1. Upload SELURUH isi folder ini ke hosting HTTPS (Netlify: drag & drop folder di app.netlify.com/drop).
2. Firebase Console → Authentication → Settings → Authorized domains → tambahkan domain baru Anda. Tanpa ini login Google akan gagal.
3. Buka situs di HP (Chrome/Edge): muncul tombol "Install" atau menu ⋮ → "Instal aplikasi".
   iPhone: Safari → Bagikan → "Tambah ke Layar Utama".

## Catatan keamanan
- Firebase apiKey memang publik, tapi keamanan datanya bergantung pada Firebase Security Rules. Pastikan rules Firestore membatasi data per pengguna.
- API key ImgBB terlihat di kode. Siapa pun bisa memakainya. Pertimbangkan membuat key baru dan/atau memindahkan upload lewat backend.

## Fitur baru (v2)
- Ikon & logo: memakai logo Doa Ibu (icons/logo-512.png), tidak lagi bergantung ImgBB.
- Tab **Galeri**: kumpulan semua chart dari Journal (hasil trading) dan Market Outlook (mapping), dikelompokkan per bulan, bisa difilter dan diurutkan terbaru/terlama. Klik foto untuk zoom.
- Tab **Diary**: rencana harian (checklist), mood, dan catatan. Tersimpan di Firestore: users/{uid}/diaries/{tanggal}.

## PENTING: Firestore Security Rules
Diary memakai koleksi baru "diaries". Jika rules Anda hanya mengizinkan "journals" dan "outlooks", diary akan gagal disimpan. Contoh rules yang mencakup semuanya:

    rules_version = '2';
    service cloud.firestore {
      match /databases/{database}/documents {
        match /users/{uid} {
          allow read, write: if request.auth != null && request.auth.uid == uid;
          match /{document=**} {
            allow read, write: if request.auth != null && request.auth.uid == uid;
          }
        }
      }
    }

## Fitur baru (v3): Pengingat Journal
- Tombol lonceng di header → atur pengingat: aktif/nonaktif, jam, hari aktif, ulangi tiap 30 menit / 1 jam / 2 jam (maks. 3 kali), pesan kustom, getar, dan tombol "Tes notifikasi".
- Pengingat hanya muncul jika **belum ada journal untuk hari itu**. Begitu journal hari ini tersimpan, banner dan notifikasi otomatis hilang.
- Pengaturan tersimpan di Firestore pada dokumen `users/{uid}` (field `reminder`), jadi ikut ke perangkat lain. Tidak perlu mengubah Security Rules.
- File baru: `reminder-core.js` (logika bersama halaman & service worker). `sw.js` naik ke v3 (jangan lupa upload semua file).

### Cara kerja & batasannya (penting)
1. **Aplikasi terbuka**: banner "Kamu belum mengisi journal hari ini" muncul di dashboard.
2. **Aplikasi di latar belakang**: notifikasi sistem dikirim tepat waktu selama halaman masih hidup.
3. **Aplikasi tertutup**: memakai Periodic Background Sync (Chrome Android, aplikasi sudah diinstal). Browser yang menentukan seberapa sering ini jalan, jadi TIDAK dijamin tepat jam.
4. Untuk pengingat yang benar-benar tepat waktu walau aplikasi tertutup, dibutuhkan push server (Firebase Cloud Messaging + Cloud Functions terjadwal). Itu butuh paket Firebase Blaze.
5. iPhone/iPad: notifikasi hanya berfungsi bila aplikasi sudah ditambahkan ke Layar Utama (iOS 16.4+).
- Pengguna harus mengizinkan notifikasi saat mengaktifkan pengingat. Jika ditolak, banner di dalam aplikasi tetap berfungsi.
- Menekan notifikasi membuka aplikasi langsung ke form journal baru (juga tersedia sebagai shortcut ikon aplikasi).

## Perbaikan tampilan Android
- Tab bar tidak lagi terpotong di kiri/kanan: bisa digeser, ada fade di tepi, dan tab aktif otomatis ke tengah.
- Header lebih ringkas di HP: profil mengisi ruang sisa, tombol Logout jadi ikon, teks "Edit profil" dipersingkat.
- Tanggal "hari ini" kini memakai waktu lokal perangkat (sebelumnya UTC, sehingga jam 00:00-07:00 WIB tanggalnya masih kemarin).

## Tampilan v4: iOS 27 Liquid Glass
- **Font**: memakai SF Pro (font sistem iOS 27) lewat `-apple-system`. Otomatis aktif di iPhone/iPad/Mac. Lisensi Apple tidak mengizinkan SF Pro di-upload ke web, jadi di Android/Windows dipakai **Inter** (padanan terdekat, ada optical size Text ↔ Display seperti SF Pro). Plus Jakarta Sans sudah dilepas.
- **Kaca (Liquid Glass) gaya iOS 27**: blur lebih tebal supaya teks terbaca, tepi gelap tipis, highlight specular lebih terang, rim cahaya di sudut atas-kiri dan bawah-kanan.
- **Gelembung**: tab aktif, tombol emas, tombol + (FAB), chip, dan saklar berbentuk bubble kaca (saklar & slider punya "jempol" kaca memanjang seperti iOS 26/27).
- **Slider Transparansi Kaca** (baru di iOS 27): klik profil di kiri atas → geser "Transparansi Kaca" dari *Jernih* sampai *Pekat*. Tersimpan di perangkat (`localStorage: glassLevel`).
- **Toolbar seragam**: header punya blur bertahap + gradasi saat konten di-scroll di bawahnya, jadi teks tidak bertabrakan.
- **Aksesibilitas**: otomatis patuh pada "Reduce Transparency", "Increase Contrast", dan "Reduce Motion" di pengaturan perangkat.
- **Latar**: orb emas/amber lembut yang bergerak pelan di belakang kaca. Bisa dimatikan dengan menghapus blok `body::before` di CSS.
- Semua gaya baru ada di satu blok CSS di akhir `<style>` (diberi judul "iOS 27 · LIQUID GLASS LAYER"). Ubah `--lg` di `:root` untuk mengatur tingkat kaca bawaan (0 = jernih, 1 = pekat).
- `sw.js` naik ke v4. Upload semua file lagi supaya cache lama terganti.

## v7: Before vs After + Tag Gallery
- **Diary & Review → Before vs After**: pilih tanggal yang punya Market Outlook (Before), isi Actual bias, apa yang terjadi, perubahan market, refleksi (After). Muncul verdict sesuai/meleset dan akurasi bias. Tersimpan di Firestore `outlooks/{tanggal}.after` (rules tidak perlu diubah).
- **Galeri**: tiap chart bisa diberi tag Entry / SL / TP / Liquidity / FVG / OB / MSS / BOS + filter tag. Tersimpan di dokumen `users/{uid}` field `galleryTags`.
- `sw.js` naik ke v7. Upload semua file, lalu hapus cache PWA.

## v9: Sinkron Firestore + tombol Install di header
- **Review (Diary & Review → Review)** kini tersimpan di Firestore: `users/{uid}/reviews/{daily|weekly|monthly}_{tanggal-awal}`. Sebelumnya hanya di localStorage (per perangkat). Review lama di perangkat itu otomatis dimigrasi ke Firestore saat periodenya dibuka.
- **Diary** (`users/{uid}/diaries/{tanggal}`) dan **Before vs After** (`users/{uid}/outlooks/{tanggal}.after`) kini sinkron real-time: perubahan dari perangkat lain muncul otomatis tanpa reload. Pilihan tanggal Before vs After juga mencakup tanggal yang punya journal (tidak harus punya Market Outlook).
- Tombol simpan menampilkan status "Menyimpan…", pesan jelas bila offline, dan pesan khusus bila ditolak Security Rules.
- **Tombol Install** dipindah dari bawah layar ke header (ikon panah unduh di sebelah lonceng). Muncul hanya bila aplikasi bisa dipasang; di iPhone/iPad menampilkan petunjuk "Tambah ke Layar Utama".
- **Security Rules**: koleksi baru `reviews` tercakup oleh rules contoh di atas (`match /{document=**}` di bawah `users/{uid}`). Jika rules Anda menyebut koleksi satu per satu, tambahkan `reviews` dan `diaries`.
- `sw.js` naik ke v9. Upload semua file, lalu tutup dan buka ulang aplikasi (atau hapus cache PWA).

## Update v10/v11 — Checklist kustom & Rekap Evaluasi

**Pre-Trade Checklist bisa diatur sendiri**
- Ketuk **✎ Atur** di kartu Pre-Trade Checklist: ubah teks, hapus, atau tambah poin (maks. 15). Tekan **Selesai** untuk menutup mode edit.
- Tombol **Kembalikan ke bawaan** memulihkan 7 poin awal.
- Tersimpan di localStorage dan disinkronkan ke Firestore pada `users/{uid}.checklistItems` (dokumen yang sama dengan `galleryTags`, jadi **Firestore Rules tidak perlu diubah**).
- Centang harian kini disimpan berdasarkan ID poin, sehingga mengubah urutan/isi checklist tidak merusak data lama.

**Rekap Evaluasi saat aplikasi dibuka**
- Setelah login, muncul popup berisi rangkuman dari Review (kolom "Apa yang salah", "Yang diperbaiki berikutnya", "Apa yang berjalan baik") dan refleksi "After" di Market Outlook, dari hari-hari sebelumnya (refleksi hari ini tidak ikut).
- Poin "Yang diperbaiki" terbaru ditampilkan sebagai **Fokus Hari Ini**.
- Popup muncul sekali per sesi buka aplikasi (dan lagi jika aplikasi ditinggal >30 menit). Ada opsi "Jangan tampilkan lagi hari ini".
- Bisa dibuka manual lewat panel Notifikasi di Dashboard: "📖 Baca rekap evaluasi sebelumnya".
- Membaca koleksi `reviews` dan `outlooks` yang sudah punya izin di Rules.

**v11:** rekap kini juga memuat tulisan hari ini, dan popup tampil langsung saat aplikasi dibuka (dari cache terakhir, lalu disegarkan dari server).

## v12: Rekap evaluasi otomatis saat aplikasi dibuka
- Popup "Rekap Evaluasi" kini muncul **setiap kali aplikasi dibuka/dimuat ulang** (bukan sekali per sesi tab). Tersedia opsi "Jangan tampilkan popup lagi hari ini".
- Kartu **Notifikasi** di Dashboard langsung menampilkan ringkasan (fokus, kesalahan, refleksi, catatan journal, diary, hal yang baik) tanpa perlu dipencet. "Lihat selengkapnya" membuka versi lengkap.
- Sumber data ditambah: catatan journal & diary hari sebelumnya (selain Review dan Refleksi After).
- `sw.js` naik ke v12: upload semua file agar cache lama diganti.

## v13: Pilihan mata uang akun (USD / USC / IDR)
- **Cara mengatur**: klik profil di kiri atas → bagian **Mata Uang Akun** → pilih **USD**, **USC** (US Cent), atau **IDR** (Rupiah). Langsung berlaku di seluruh aplikasi, tanpa perlu menekan Simpan Profil.
- **Tersimpan** di perangkat (`localStorage`) dan disinkronkan ke Firestore pada `users/{uid}.currency` (dokumen yang sama dengan profil, jadi **Firestore Rules tidak perlu diubah**). Login di perangkat lain otomatis memakai pilihan yang sama. Bawaan tetap USD, jadi pengguna lama tidak melihat perubahan sampai memilih sendiri.
- **PENTING: angka tidak dikonversi.** Pilihan ini hanya mengubah simbol dan format. Nilai P/L yang sudah tersimpan tetap apa adanya. Jadi pilih mata uang yang sesuai akun sejak awal; jika mengganti di tengah jalan, data lama akan dibaca sebagai mata uang baru.
- **Format**: USD `+$1,250.00` · USC `+¢12,500.00` · IDR `+Rp 1.250.000` (tanpa desimal, pemisah titik).
- **Anti-glitch untuk angka besar (Rupiah)**:
  - Sel kalender memakai format ringkas: `+988jt`, `-12,3jt`, `-250rb`, `+1,25M` (rb = ribu, jt = juta, M = miliar, T = triliun). Nominal lengkap muncul saat sel di-hover/ditahan (tooltip).
  - Kartu statistik otomatis mengecilkan font agar nominal panjang seperti `+Rp 2.222.088.654` tetap satu baris dan tidak meluber. Bila masih terlalu panjang di layar sangat kecil, teks dipotong dan nominal lengkap ada di tooltip.
  - Sumbu Y grafik memakai format ringkas (`500rb`, `1,5jt`).
  - Kartu Best Day / Worst Day menaruh nominal di atas dan tanggal di baris kecil di bawahnya.
- **Form input**: placeholder menyesuaikan (`150000 atau -80000` untuk IDR), label menampilkan satuan (`P/L Hari Ini (Rp)`), dan di bawah kolom P/L ada **pratinjau langsung** (`= +Rp 1.500.000`) untuk memastikan jumlah nol sudah benar.
- **Lainnya yang ikut menyesuaikan**: kartu journal, breakdown pair/sesi, Max Drawdown, Expectancy, Risk Calculator (label Balance), heatmap, Review, Edge Finder, preview import broker, notifikasi gabung journal, dan PDF export (total). Export CSV/Excel/PDF menambah kolom **Mata Uang**; nilai P/L di CSV/Excel tetap angka mentah.
- `sw.js` naik ke v13. Upload semua file, lalu tutup dan buka ulang aplikasi (atau hapus cache PWA).


## V16.2: Setup Performance (tab Statistik)
- Kartu per setup (dari kolom "Setup / Strategy Tag"): total trade, win/loss, win rate, net P/L, avg win/loss, profit factor, expectancy, avg R, streak terpanjang.
- Breakdown: Setup × Pair, Setup × Session, Setup × Direction (Direction = bias Long/Short; Neutral/campuran tidak ditebak).
- "View Trades" membuka daftar journal/trade pembentuk angka, lengkap dengan tombol "Buka journal".
- Di bawah 10 trade: ditampilkan "Insufficient data" untuk rasio (win rate, PF, expectancy). 10-29 = "Sample kecil", 30+ = "Sample cukup".
- Mode **Eksak** (default): hanya hari dengan satu nilai tunggal. Mode **Inklusif**: hari dengan beberapa setup/pair/session dihitung di tiap nilainya (P/L ganda, ditandai "shared").
- Journal lama hanya punya total per hari, jadi avg win/loss, streak, dan P/L dihitung per hari (diberi label). Avg R = N/A sampai ada data R per trade.
- Tidak ada perubahan skema Firestore; data V15 tidak disentuh. File yang berubah: index.html, v16-stats.js, sw.js (upload ulang semuanya). Tes: `node tests/sp-test.js` (butuh Playwright).

## V16.3: Edge Finder 2.0 (tab Statistik)
- Menggantikan kartu Edge Finder lama. Kombinasi: Pair × Session, Pair × Setup, Setup × Session, Setup × Direction, Session × Hari. Setup × Market muncul hanya jika ada data market per trade.
- Tiap kombinasi menampilkan sample, win rate, net P/L, expectancy, profit factor, avg R (N/A bila tidak ada data R), kalimat deskriptif historis, dan tombol "View Trades".
- Status: Not enough data (<10 trade, rasio disembunyikan), Historical pattern (10–29), Sufficient sample (≥30).
- Filter: tanggal, pair, session, setup, direction; mode Eksak/Inklusif seperti V16.2.
- Tidak ada prediksi atau klaim profit; tidak ada perubahan skema Firestore. File berubah: index.html, sw.js (v16-3). Upload ulang semuanya.

## V16.4: Psychology Analytics + Trading Score (Statistik)
Dua panel baru di tab Statistik, di bawah Edge Finder. Semua angka dihitung dari data kamu, tanpa data dummy.

**Psychology Analytics** (deskriptif, bukan sebab-akibat)
- Emotion × Hasil: jumlah trade, win rate, net P/L, expectancy per emotion tag.
- Emotion × Setup, × Session, × Mistake Tag.
- Kalimat ringkasan berbunyi, misalnya: "Trade yang diberi tag FOMO memiliki win rate 39%." Tidak ada klaim "FOMO menyebabkan loss".
- Kurang dari 10 trade = **Insufficient data**; 10–29 = Sample kecil; 30+ = Sample cukup.
- Mode **Semua tag**: hari dengan beberapa emotion dihitung di tiap tag (ditandai "shared"). Mode **Tag tunggal**: hanya hari dengan satu tag.
- Mistake Tag: journal V15 belum punya field ini, jadi tampil "Insufficient data" sampai ada data `tradeLog[].mistake`.

**Trading Score** (kualitas eksekusi 0–100, P/L tidak masuk hitungan)
| Komponen | Bobot | Sumber data |
|---|---|---|
| Risk Management | 25 | Risk calculator hari itu (sesuai batas = 100, melebihi = 0) |
| Plan Adherence | 20 | Tugas "Rencana hari ini" di Diary yang selesai |
| Entry Quality | 15 | Belum ada data di journal V15 (No data) |
| Exit Management | 15 | Belum ada data di journal V15 (No data) |
| Emotion Control | 15 | Porsi emotion tag non-negatif (Fearful, FOMO, Anxious, Revenge, Greedy, Frustrated = negatif) |
| Checklist Completion | 10 | Checklist pre-trade yang dicentang |
- Komponen tanpa data tidak dihitung dan tidak diberi angka. Skor harian butuh minimal 2 komponen; kurang dari itu tampil Insufficient data.
- Checklist dan Risk calculator tersimpan di perangkat (localStorage), jadi skor memakai data dari perangkat yang sedang dipakai.
- Field opsional per trade bila suatu saat ditambahkan: `tradeLog[].followedPlan`, `entryScore`, `exitScore`, `mistake`, `emotion`.
- `sw.js` naik ke v16-4. Upload semua file, lalu hapus cache PWA.
- Tes: `node tests/ps-test.js` (V16.4) dan `node tests/sp-test.js` (V16.2).

## V16.5 (Prompt 1/2): Dashboard baru + Review Bulanan
- **Dashboard** (tab pertama) kini berisi: 6 KPI (Net P/L, Win Rate, Profit Factor, Expectancy, Max Drawdown, Total Trades), Equity Curve, Monthly Calendar Heatmap, Setup Performance, Edge Finder Insights, Psychology Snapshot, dan Recent Trade Review. Desktop memakai grid 2 kolom, mobile menumpuk kartu.
- Tampilan Dashboard V15 lama (KPI, grafik P/L, filter 7D/30D/90D) **tidak dihapus**: dilipat di bagian "Tampilan Dashboard V15 (klasik)". Risk Calculator dan Pre-Trade Checklist tetap di bawahnya.
- **Review Bulanan** (tab baru): pilih bulan, lihat 14 metrik, catatan "What Went Well" / "What Needs Improvement" yang dihasilkan dari data, dan "Focus for Next Month" yang diisi manual. Catatan fokus tersimpan di `users/{uid}/reviews/focus_{YYYY-MM}` (koleksi `reviews` yang sama dengan Review V9, tidak perlu mengubah Rules) dan di perangkat sebagai cadangan.
- Semua angka dihitung dari journal lewat `v16-stats.js` (fungsi baru: `monthReview`, `dashboardSummary`, `calendarMonth`, `equityByDay`, dst). Tidak ada data dummy dan tidak ada rekomendasi trading otomatis.
- Data yang memang belum dicatat aplikasi (Average R per trade, Mistake Tag) tampil sebagai **N/A / "Belum ada data"**, bukan angka karangan.
- `loadJournals()` kini mengirim event `journals-error` saat gagal, supaya Dashboard bisa menampilkan state error + tombol "Coba lagi".
- Hook untuk Prompt 2 (Global Filter): `window.V165.state.filters = {from,to,pair,session,setup,direction,emotion,tag,result}` lalu `V165.renderAll()`.
- `sw.js` naik ke v16-5. Upload semua file, lalu hapus cache PWA.
- Tes: `node tests/v165-test.js` (modul) dan `node tests/v165-app-test.js` (aplikasi asli vs baseline V16.4).
## V16.5 (Prompt 2/2): Global Filter + Quality Control + Final Polish
- **Global Filter** muncul di atas Dashboard dan Review Bulanan (satu state yang sama). Tombol "Filter" membuka 9 pilihan: Dari tanggal, Sampai tanggal, Pair, Session, Setup, Direction, Result, Tags, Emotion. Pilihan Pair/Session/Setup/Tags/Emotion hanya berisi nilai yang benar-benar ada di journalmu.
- Filter aktif tampil sebagai chip (klik untuk menghapus satu filter) dan ringkasan "Menampilkan X dari Y trade". Tombol **Clear All Filters** menghapus semuanya. Jika tidak ada data yang cocok, muncul empty state dengan tombol Clear All Filters.
- **Sinkron dengan filter Journal V15** (dua arah): tanggal, pair, session, tag, dan arah (Long/Short). Mengubah filter di daftar Journal ikut mengubah Dashboard, dan sebaliknya. Setup, Result, dan Emotion hanya ada di filter global. Arah "Neutral" di daftar Journal tidak punya padanan di Dashboard, jadi tidak dipaksakan. Filter tidak disimpan setelah halaman ditutup (sama seperti filter Journal V15).
- **Journal harian dengan beberapa nilai** (misalnya dua pair): ikut tersaring bila salah satu nilainya cocok, sama seperti filter Journal V15. P/L hari itu dihitung utuh karena tidak ada rincian per trade, dan Dashboard memberi catatan jujur soal ini.
- **Result** memakai P/L: per trade bila ada `tradeLog`, per hari untuk journal harian.
- **QC**: angka journal yang rusak (teks/kosong) dirapikan di memori saat dimuat (Firestore tidak diubah), sehingga V15 klasik dan V16 tidak menampilkan NaN. Ada state loading (skeleton), error (+ Coba lagi, termasuk bila memuat >15 detik), dan empty. Overflow horizontal 2px di Statistik pada layar sempit diperbaiki.
- **Polish**: teks terkecil di modul V16 naik ke 13px, grid filter 3 kolom di desktop dan 2 kolom di mobile, kontrol minimal 40px, fokus keyboard terlihat dan tetap di tempat setelah filter berubah.
- Fungsi baru di `v16-stats.js`: `filterOptions(units)` dan opsi `applyFilters(units, f, {inclusive:true})`. Perilaku default `applyFilters` untuk modul Statistik tidak berubah.
- `sw.js` naik ke v16-5-2. Upload semua file, lalu hapus cache PWA.
- Tes baru: `node tests/v165-filter-test.js` (filter, sinkron V15, state) dan `node tests/v165-audit.js` (audit NaN/overflow/font di semua view V16).

## v16.9: Emas mengkilap, Teal/Coral, Liquid Glass
- **Header emas foil**: semua judul/label berwarna kuning kini memakai gradien emas metalik (palet dari logo) dengan kilau yang bergeser pelan. Mati otomatis bila perangkat memakai "Reduce Motion".
- **Profit = Teal, Loss = Coral**: satu nada untuk seluruh app (teks, chip, bar, grafik, kalender). Mode gelap `#2dd4bf` / `#ff7a68`, mode terang `#0f766e` / `#b83526` (kontras ≥ 4.5:1).
- **Liquid Glass emas**: blur lebih tebal, pita cahaya diagonal, specular kiri-atas, bloom emas kanan-bawah, bingkai emas bercahaya, latar dengan pendar emas ala logo, tombol & tab aktif berbentuk batang emas cair.
- Semua gaya baru ada di blok `<style id="luxe-v169">` di akhir `index.html`. `sw.js` naik ke v16-9-0: upload semua file agar cache lama terganti.


## V16.11
- Before vs After & Review dipindah dari Statistik ke tab **Diary & Review** (logika form sama).
- Perbaikan: checklist pre-trade tidak lagi membuat halaman naik-turun saat dicentang.
- Dihapus: "Tampilan Dashboard V15 (klasik)".
- Lapisan warna baru (aurora lembut, kilau emas, aksen emerald) tanpa mengubah logika.

## v16.12: Halaman awal baru + perbaikan glow hijau
- **Glow hijau tertinggal dihapus**: blob teal/ungu di latar belakang (`#vibe-ambient`) diganti hangat/emas redup, tint teal pada kartu kaca & hero statistik dihapus. Efek glow pada angka profit/loss tetap ada, tetapi hanya di teks (radius kecil), tidak menyebar ke background sel kalender.
- **Landing page baru**: preview aplikasi (data ilustrasi), siklus 4 langkah (Rencanakan, Catat, Evaluasi, Perbaiki), kartu semua fitur, panel "Cara Mengisi" (Sebelum Trade, Setelah Trade, Refleksi) berisi daftar isian + contoh, 3 kebiasaan trader, dan tombol CTA.
- Teks landing tersedia lengkap dalam Indonesia & English. Melayu memakai teks Indonesia dan Español memakai teks English (terjemahan penuh bisa ditambah di objek `LP_ID` / `LP_EN` lalu salin ke `I18N.ms` / `I18N.es`).
- `sw.js` naik ke v16-12-0. Upload semua file, lalu tutup & buka ulang PWA agar cache lama terganti.

## v16.12.1: Rotasi layar
- `manifest.webmanifest`: `"orientation"` diubah dari `portrait` menjadi `any`, sehingga aplikasi yang di-install bisa berputar otomatis ke landscape mengikuti perangkat. Tidak ada kode yang mengunci orientasi di `index.html`.
- **Penting:** Android menyimpan manifest saat aplikasi di-install. Hapus aplikasi lama dari layar utama lalu install ulang dari browser agar pengaturan baru terpakai. Pastikan juga "Putar otomatis" aktif di HP/tablet.
- `sw.js` naik ke v16-12-1.

---

## Sistem Tema Dark/Light (v16.12.2)

| File | Fungsi |
|---|---|
| `theme.js` | Toggle tema, simpan di `localStorage` (key `themeMode`), deteksi tema OS. Dimuat paling awal di `<head>`. |
| `styles.css` | Token warna `--app-*` / `--trade-*` untuk Dark (default, `:root`) dan Light (`[data-theme="light"]`). |
| `tailwind.config.js` | Menghubungkan token ke Tailwind: `bg-app-surface`, `text-app-muted`, `text-trade-profit`, `bg-trade-loss/10`, `bg-app-gold`, dst. |

- Urutan tema: pilihan manual pengguna, lalu tema OS (OS terang = light, selain itu dark).
- `DoaTheme.set('system')` menghapus pilihan manual dan kembali mengikuti OS.
- Event `themechange` di `window` dipakai untuk menggambar ulang grafik.
- Class lama (`bg-dark-*`, `text-gray-*`) tetap ditangani oleh aturan `body.light`; `theme.js` menyinkronkan class itu otomatis.
