// Design system checks: kontras WCAG, fokus, reduced-motion, overflow, dan "tidak ada efek samping" ke aplikasi lama.
const { chromium } = require('/home/claude/.npm-global/lib/node_modules/playwright');
const path = require('path'), fs = require('fs');
const out = '/home/claude/shots'; fs.mkdirSync(out, { recursive: true });
let fails = 0; const ok = (c, m) => { console.log((c ? 'PASS ' : 'FAIL ') + m); if (!c) fails++; };
const url = 'file://' + path.join(__dirname, '..', 'design-system', 'preview.html');

(async () => {
  const browser = await chromium.launch();
  for (const light of [false, true]) {
    for (const [w, h] of [[390, 844], [1280, 900]]) {
      const ctx = await browser.newContext({ viewport: { width: w, height: h } });
      const p = await ctx.newPage(); const errs = [];
      p.on('pageerror', e => errs.push(e.message));
      await p.goto(url);
      if (light) { await p.evaluate(() => document.body.classList.add('light')); await p.waitForTimeout(400); }
      const tag = (light ? 'light' : 'dark') + '-' + w;
      ok(errs.length === 0, tag + ': no JS errors');
      const overflow = await p.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
      ok(overflow <= 0, tag + ': no horizontal overflow (' + overflow + 'px)');

      // kontras: komposit warna latar + teks (alpha) lalu hitung rasio WCAG
      const res = await p.evaluate(() => {
        const parse = c => { const m = c.match(/[\d.]+/g).map(Number); return { r: m[0], g: m[1], b: m[2], a: m[3] === undefined ? 1 : m[3] }; };
        const over = (f, b) => ({ r: f.r * f.a + b.r * (1 - f.a), g: f.g * f.a + b.g * (1 - f.a), b: f.b * f.a + b.b * (1 - f.a), a: 1 });
        const lum = c => { const f = v => { v /= 255; return v <= .03928 ? v / 12.92 : Math.pow((v + .055) / 1.055, 2.4); }; return .2126 * f(c.r) + .7152 * f(c.g) + .0722 * f(c.b); };
        const ratio = (a, b) => { const x = lum(a), y = lum(b); return (Math.max(x, y) + .05) / (Math.min(x, y) + .05); };
        const stack = el => { const chain = []; for (let e = el; e; e = e.parentElement) chain.push(getComputedStyle(e).backgroundColor); let bg = parse(getComputedStyle(document.body).backgroundColor); if (bg.a < 1) bg = over(bg, { r: 255, g: 255, b: 255, a: 1 }); for (const c of chain.reverse()) { const q = parse(c); if (q.a > 0) bg = over(q, bg); } return bg; };
        const test = sel => { const el = document.querySelector(sel); const bg = stack(el); const fg = over(parse(getComputedStyle(el).color), bg); return +ratio(fg, bg).toFixed(2); };
        return {
          body_secondary: test('.ds-body'), caption: test('.ds-caption'), title: test('.ds-title'),
          primary_btn: test('.ds-btn--primary'), secondary_btn: test('.ds-btn--secondary'), destructive: test('.ds-btn--destructive'),
          win: test('.ds-badge--win'), loss: test('.ds-badge--loss'), open: test('.ds-badge--open'), long: test('.ds-badge--long'), short: test('.ds-badge--short'),
          input: test('.ds-input'), error: test('.ds-error')
        };
      });
      const fail = Object.entries(res).filter(([k, v]) => v < 4.5);
      ok(fail.length === 0, tag + ': semua teks ≥ 4.5:1  ' + (fail.length ? 'GAGAL=' + JSON.stringify(fail) : ''));
      if (!light && w === 1280) console.log('   kontras (dark):', JSON.stringify(res));
      if (light && w === 1280) console.log('   kontras (light):', JSON.stringify(res));

      if (w === 1280) {
        // fokus keyboard terlihat
        await p.keyboard.press('Tab'); await p.keyboard.press('Tab');
        const focused = await p.evaluate(() => { const e = document.activeElement; const s = getComputedStyle(e); return { tag: e.tagName, shadow: s.boxShadow }; });
        ok(/rgb/.test(focused.shadow) && focused.shadow !== 'none', tag + ': fokus keyboard menampilkan ring (' + focused.tag + ')');
        // elemen yang bisa difokus: tombol disabled tidak ikut
        const dis = await p.evaluate(() => { const b = document.querySelector('.ds-btn--primary[disabled]'); b.focus(); return document.activeElement === b; });
        ok(!dis, tag + ': tombol disabled tidak bisa difokus');
        // radius hanya dari skala
        const radii = await p.evaluate(() => { const set = new Set(); document.querySelectorAll('[class*="ds-"]').forEach(e => set.add(getComputedStyle(e).borderTopLeftRadius)); return [...set]; });
        const allowed = new Set(['0px', '12px', '16px', '20px', '24px', '28px', '999px', '50%', '16.5px', '33554400px']);
        const stray = radii.filter(r => !allowed.has(r));
        ok(stray.length === 0, tag + ': radius hanya dari skala  ' + (stray.length ? JSON.stringify(stray) : ''));
        // tidak ada font-weight 800+
        const heavy = await p.evaluate(() => [...document.querySelectorAll('main *')].filter(e => +getComputedStyle(e).fontWeight >= 800).length);
        ok(heavy === 0, tag + ': tidak ada font-weight ≥ 800');
        await p.screenshot({ path: `${out}/ds-${tag}.png`, fullPage: true });
      }
      await ctx.close();
    }
  }
  // reduced motion
  const ctx = await browser.newContext({ reducedMotion: 'reduce', viewport: { width: 1280, height: 900 } });
  const p = await ctx.newPage(); await p.goto(url);
  const tr = await p.evaluate(() => ['.ds-btn', '.ds-input', '.ds-surface--interactive'].map(s => getComputedStyle(document.querySelector(s)).transitionDuration));
  ok(tr.every(t => t === '0s'), 'reduced-motion: transisi dimatikan ' + JSON.stringify(tr));
  // durasi normal 150–250ms
  const ctx2 = await browser.newContext({ viewport: { width: 1280, height: 900 } }); const p2 = await ctx2.newPage(); await p2.goto(url);
  const dur = await p2.evaluate(() => ['.ds-btn--primary', '.ds-input', '.ds-surface--interactive'].map(s => getComputedStyle(document.querySelector(s)).transitionDuration));
  const okDur = dur.every(d => d.split(',').every(x => { const ms = parseFloat(x) * (x.includes('ms') ? 1 : 1000); return ms >= 150 && ms <= 250; }));
  ok(okDur, 'durasi transisi 150–250ms ' + JSON.stringify(dur));
  await browser.close();
  console.log(fails ? '\nFAILED: ' + fails : '\nALL PASSED');
  process.exit(fails ? 1 : 0);
})();
