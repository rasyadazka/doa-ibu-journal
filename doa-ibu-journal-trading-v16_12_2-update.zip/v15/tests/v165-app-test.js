// Integration test: loads the REAL index.html with Firebase/CDNs stubbed, runs the same flow on the ORIGINAL V16.4 and on V16.5 and compares.
const { chromium } = require('/home/claude/.npm-global/lib/node_modules/playwright');
const { sets } = require('./v165-harness');
const fs = require('fs'), path = require('path');
const out = '/home/claude/shots'; fs.mkdirSync(out, { recursive: true });
let fails = 0; const ok = (c, m) => { console.log((c ? 'PASS ' : 'FAIL ') + m); if (!c) fails++; };
const DIRS = { new: path.join(__dirname, '..'), old: '/home/claude/orig/v15' };
const FB = (journals) => `(function(){
 var store=window.__store={'users/u1/journals':{}};
 ${JSON.stringify(journals)}.forEach(function(j){store['users/u1/journals'][j.id]=Object.assign({},j);delete store['users/u1/journals'][j.id].id});
 var mkSnap=function(m){var ds=Object.keys(m||{}).map(function(k){return{id:k,data:function(){return m[k]}}});return{forEach:function(f){ds.forEach(f)},size:ds.length,empty:!ds.length,docs:ds}};
 function col(p){return{doc:function(id){return doc(p+'/'+id)},orderBy:function(){return this},limit:function(){return this},where:function(){return this},
  get:function(){return Promise.resolve(mkSnap(store[p]))},onSnapshot:function(cb){setTimeout(function(){cb(mkSnap(store[p]))},0);return function(){}},add:function(v){return Promise.resolve({id:'x'})}}}
 function doc(p){var a=p.split('/'),id=a.pop(),c=a.join('/');return{collection:function(n){return col(p+'/'+n)},
  get:function(){var d=(store[c]||{})[id];return Promise.resolve({exists:!!d,id:id,data:function(){return d||{}}})},
  set:function(v,o){store[c]=store[c]||{};store[c][id]=Object.assign({},o&&o.merge?store[c][id]:{},v);return Promise.resolve()},
  update:function(v){store[c]=store[c]||{};store[c][id]=Object.assign({},store[c][id],v);return Promise.resolve()},
  delete:function(){if(store[c])delete store[c][id];return Promise.resolve()},
  onSnapshot:function(cb){setTimeout(function(){var d=(store[c]||{})[id];cb({exists:!!d,id:id,data:function(){return d||{}},metadata:{hasPendingWrites:false}})},0);return function(){}}}}
 var db={collection:function(n){return col(n)}};
 var user={uid:'u1',displayName:'Tester',email:'t@x.com',photoURL:''};
 var auth={onAuthStateChanged:function(cb){setTimeout(function(){cb(user)},0);return function(){}},signInWithPopup:function(){return Promise.resolve()},signOut:function(){return Promise.resolve()},currentUser:user};
 window.firebase={initializeApp:function(){},apps:[],auth:Object.assign(function(){return auth},{GoogleAuthProvider:function(){}}),firestore:Object.assign(function(){return db},{FieldValue:{serverTimestamp:function(){return Date.now()},delete:function(){return null},arrayUnion:function(){return[]},increment:function(n){return n}},FieldPath:{documentId:function(){return '__id__'}}})};
})();`;
async function run(which, journals, w, light) {
  const dir = DIRS[which], b = await chromium.launch();
  const ctx = await b.newContext({ viewport: { width: w, height: w < 700 ? 844 : 900 } });
  await ctx.route('**/*', async r => {
    const u = new URL(r.request().url());
    if (u.hostname === 'app.local') { let f = u.pathname === '/' ? '/index.html' : u.pathname; const fp = path.join(dir, f); return fs.existsSync(fp) ? r.fulfill({ body: fs.readFileSync(fp), contentType: f.endsWith('.js') ? 'application/javascript' : f.endsWith('.html') ? 'text/html' : 'application/octet-stream' }) : r.fulfill({ status: 404, body: '' }); }
    if (/firebase-app-compat/.test(u.href)) return r.fulfill({ contentType: 'application/javascript', body: FB(journals) });
    if (/tailwindcss/.test(u.href)) return r.fulfill({ contentType: 'application/javascript', body: 'window.tailwind={};' });
    if (/Chart\.js/.test(u.href)) return r.fulfill({ contentType: 'application/javascript', body: 'window.Chart=function(){this.destroy=function(){}};' });
    return r.fulfill({ contentType: 'application/javascript', body: '' });
  });
  await ctx.addInitScript(() => { localStorage.setItem('journalLanguage', 'id'); });
  const p = await ctx.newPage(); const errs = []; p.on('pageerror', e => errs.push('pageerror: ' + e.message)); p.on('console', m => m.type() === 'error' && !/Failed to load resource|ERR_|net::/.test(m.text()) && errs.push('console: ' + m.text().slice(0, 140)));
  p.on('dialog', d => { errs.push('dialog: ' + d.message()); d.dismiss(); });
  await p.addInitScript(() => { const s = document.createElement('style'); s.textContent = '.hidden{display:none!important}'; document.addEventListener('DOMContentLoaded', () => document.head.appendChild(s)); });
  await p.goto('http://app.local/index.html'); await p.waitForSelector('#journal-count:has-text("journal")', { timeout: 15000 }).catch(() => {});
  await p.waitForTimeout(600);
  if (light) { await p.click('#btn-theme-toggle'); await p.waitForTimeout(200); }
  return { p, b, errs };
}
(async () => {
  const data = sets.rich.map(j => Object.assign({}, j));
  const res = {};
  for (const w of ['old', 'new']) {
    const { p, b, errs } = await run(w, data, 1280); res[w] = { errs: errs.slice() };
    const v15 = await p.evaluate(() => ({ pl: document.getElementById('stat-total-pl').textContent, wr: document.getElementById('stat-winrate').textContent, tr: document.getElementById('stat-total-trades').textContent, avg: document.getElementById('stat-avg-pl').textContent, pf: document.getElementById('v21-pf').textContent, dd: document.getElementById('v21-dd').textContent, cards: document.querySelectorAll('#journal-list > *').length, count: document.getElementById('journal-count').textContent }));
    res[w].v15 = v15;
    const tabs = {};
    for (const v of ['calendar', 'statistik', 'gallery', 'diary', 'web', 'dashboard']) {
      await p.click('#nav-' + v); await p.waitForTimeout(250);
      tabs[v] = await p.evaluate(v2 => { const m = { calendar: 'calendar-section', statistik: 'statistik-section', gallery: 'gallery-section', diary: 'diary-section', web: 'web-section', dashboard: 'view-dashboard' }; const e = document.getElementById(m[v2]); return e && !e.classList.contains('hidden'); }, v);
    }
    res[w].tabs = tabs;
    await p.click('#nav-statistik'); await p.waitForTimeout(300);
    res[w].stats = await p.evaluate(() => ({ sp: !!document.getElementById('sp-root'), ef: !!document.getElementById('ef-root'), ps: !!document.getElementById('ps-root'), stx: document.getElementById('stx-total-pl').textContent, spCards: document.querySelectorAll('#sp-root .sp-card').length }));
    res[w].exportRows = await p.evaluate(() => { try { return buildExportRows().length; } catch (e) { return 'ERR ' + e.message; } });
    res[w].errs = errs.slice();
    if (w === 'new') {
      await p.click('#nav-dashboard'); await p.waitForTimeout(200);
      const dash = await p.evaluate(() => ({ kpi: [...document.querySelectorAll('#v165-dash .v5-kpis .v5-kpi')].map(e => e.querySelector('.v').textContent), classic: !!document.getElementById('v165-classic'), classicOpen: document.getElementById('v165-classic').open, risk: !!document.getElementById('rk-bal'), ck: !!document.getElementById('ck-list'), secs: [...document.querySelectorAll('#v165-dash h3')].map(h => h.textContent) }));
      res.dash = dash;
      await p.click('#nav-monthly'); await p.waitForSelector('#monthly-section .v5-stats'); await p.waitForTimeout(200);
      res.monthlyVisible = await p.evaluate(() => !document.getElementById('monthly-section').classList.contains('hidden') && document.getElementById('view-dashboard').classList.contains('hidden'));
      res.monthlyKpis = await p.$$eval('#monthly-section .v5-stats .v5-kpi', els => els.length);
      await p.click('#nav-dashboard'); await p.waitForTimeout(200);
      await p.click('#v165-classic > summary'); res.classicOpens = await p.evaluate(() => document.getElementById('v165-classic').open);
      await p.click('#v165-classic > summary');
      await p.screenshot({ path: out + '/v165-app-dashboard-dark.png', fullPage: true });
      // light theme + currency change re-render
      await p.click('#btn-theme-toggle'); await p.waitForTimeout(250); await p.screenshot({ path: out + '/v165-app-dashboard-light.png', fullPage: true });
      res.light = await p.evaluate(() => document.body.classList.contains('light'));
      await p.evaluate(() => { Money.set && Money.set('IDR'); }); await p.waitForTimeout(300);
      res.idr = await p.evaluate(() => document.querySelector('#v165-dash .v5-kpi .v').textContent);
      res.errsAfter = errs.slice();
    }
    await b.close();
  }
  const o = res.old, n = res.new;
  console.log('baseline V16.4 errors:', JSON.stringify(o.errs)); console.log('V16.5 errors:', JSON.stringify(res.errsAfter));
  ok(JSON.stringify(n.v15) === JSON.stringify(o.v15), 'V15 dashboard numbers & journal list identical to V16.4 baseline ' + JSON.stringify(n.v15));
  ok(Object.values(n.tabs).every(Boolean) && Object.values(o.tabs).every(Boolean), 'V15 tabs all open (Kalender, Statistik, Galeri, Diary, Tentang, Dashboard)');
  ok(JSON.stringify(n.stats) === JSON.stringify(o.stats) && n.stats.sp && n.stats.ef && n.stats.ps, 'V16.2/16.3/16.4 modules (Setup Performance, Edge Finder, Psychology) still render in Statistik: ' + JSON.stringify(n.stats));
  ok(n.exportRows === o.exportRows && typeof n.exportRows === 'number', 'export rows unchanged (' + n.exportRows + ')');
  ok(res.errsAfter.filter(e => !o.errs.includes(e)).length === 0, 'no NEW console/page errors vs V16.4 baseline');
  ok(res.dash.kpi.length === 6 && res.dash.classic && !res.dash.classicOpen && res.dash.risk && res.dash.ck, 'V16.5 dashboard rendered; V15 classic block kept (collapsed); Risk Calculator + Checklist still present');
  ok(res.dash.secs.join('|') === 'Equity Curve|Monthly Calendar Heatmap|Setup Performance|Edge Finder Insights|Psychology Snapshot|Recent Trade Review', 'dashboard sections: ' + res.dash.secs.join(', '));
  const v15pl = parseFloat(n.v15.pl.replace(/[^0-9.\-]/g, '')), v165pl = parseFloat(res.dash.kpi[0].replace(/[^0-9.\-]/g, ''));
  ok(Math.abs(Math.abs(v15pl) - Math.abs(v165pl)) < 0.005, 'V15 Total P/L (' + n.v15.pl + ') equals V16.5 Net P/L (' + res.dash.kpi[0] + ')');
  ok(n.v15.tr === res.dash.kpi[5], 'V15 Total Trade equals V16.5 Total Trades (' + n.v15.tr + ')');
  ok(res.monthlyVisible && res.monthlyKpis === 14, 'Review Bulanan tab opens inside the real app with 14 metrics');
  ok(res.classicOpens, 'V15 classic block can be expanded');
  ok(res.light, 'theme toggle works with new blocks'); ok(/Rp/.test(res.idr), 'currency change re-renders V16.5 (' + res.idr + ')');
  console.log(fails ? '\n' + fails + ' FAILED' : '\nALL PASSED'); process.exit(fails ? 1 : 0);
})();
