const { chromium } = require('/home/claude/.npm-global/lib/node_modules/playwright');
const { page: mk, sets } = require('./ps-harness');
const V = require('../v16-stats.js');
const fs = require('fs'); const out = '/home/claude/shots'; fs.mkdirSync(out, { recursive: true });
let fails = 0; const ok = (c, m) => { console.log((c ? 'PASS ' : 'FAIL ') + m); if (!c) fails++; };

/* ---------- pure logic ---------- */
(function pure() {
  const a = V.scoreDay({ risk: true, emotions: ['Disciplined'], checklist: { done: 7, total: 7 } });
  const b = V.scoreDay({ risk: true, emotions: ['Disciplined'], checklist: { done: 7, total: 7 }, pl: -999, profit: -999 });
  ok(a.total === 100 && b.total === 100, 'pure: P/L is not a score input (loss day, same behaviour => same score)');
  ok(V.scoreDay({ emotions: ['Confident'] }).total === null, 'pure: 1 component => total null (Insufficient data)');
  const s = V.scoreDay({ risk: false, emotions: ['FOMO', 'Confident'], checklist: { done: 3, total: 7 } });
  ok(s.parts.entry === null && s.parts.exit === null && s.parts.plan === null, 'pure: components without data stay null, not 0');
  ok(s.parts.risk === 0 && s.parts.emotion === 50 && s.parts.checklist === 43, 'pure: breakdown values (risk 0, emotion 50, checklist 43)');
  ok(s.total === 24, 'pure: weighted over available components only: (0*25+50*15+42.9*10)/50 = 24 (got ' + s.total + ')');
  ok(V.scoreDay({ checklist: { done: 0, total: 0 }, plan: { done: 0, total: 0 } }).parts.checklist === null, 'pure: total=0 does not divide by zero');
  const recs = V.buildScoreRecords([{ date: '2026-02-02', pl: 5, emotions: ['Patient'] }], { checklist: { '2026-02-02': { done: 4, total: 7 } }, risk: { '2026-02-02': true } });
  const sm = V.scoreSummary(recs); ok(sm.overall !== null && sm.componentsWithData === 3, 'pure: summary uses only components with data');
  const sentence = V.describeEmotion(['FOMO'], { trades: 23, winRate: 39.13, net: -40, expectancy: -1.7 }, null, v => '$' + v);
  ok(/Trade yang diberi tag FOMO memiliki win rate 39%/.test(sentence) && !/menyebabkan|karena|akibat/i.test(sentence), 'pure: descriptive wording, no causal words: ' + sentence);
  ok(/Insufficient data/.test(V.describeEmotion(['FOMO'], { trades: 3, winRate: 33, net: 0, expectancy: 0 })), 'pure: <10 trades => Insufficient data');
})();

(async () => {
  const b = await chromium.launch();
  async function open(name, w, opts) {
    opts = opts || {};
    const ctx = await b.newContext({ viewport: { width: w, height: w < 700 ? 844 : 900 } });
    await ctx.route('http://t.local/**', r => r.fulfill({ contentType: 'text/html', body: mk(opts.data || sets[name], opts.light) }));
    if (opts.ls) await ctx.addInitScript(o => { for (const k in o) localStorage.setItem(k, o[k]); }, opts.ls);
    const p = await ctx.newPage(); const errs = []; p.on('pageerror', e => errs.push(e.message)); p.on('console', m => m.type() === 'error' && errs.push(m.text()));
    await p.goto('http://t.local/x'); await p.waitForSelector('#ps-root'); p.errs = errs; return p;
  }
  const clean = async (p, tag) => {
    const t = await p.evaluate(() => document.body.innerText);
    ok(!/NaN|undefined|Infinity|-0\.00|\[object/.test(t), tag + ': no NaN/undefined/Infinity/-0');
    ok(p.errs.length === 0, tag + ': no JS errors ' + p.errs.join('|'));
    ok(!(await p.evaluate(() => document.documentElement.scrollWidth > window.innerWidth + 1)), tag + ': no horizontal overflow');
    ok(!/menyebabkan/i.test(t), tag + ': no causal wording');
  };

  // empty
  let p = await open('empty', 1200); ok(/Your Journey Starts Here/.test(await p.innerText('#ps-emo')), 'empty: empty state');
  ok(/Insufficient data/.test(await p.innerText('#ps-score')), 'empty: score = Insufficient data'); await clean(p, 'empty');

  // journals without any emotion
  p = await open('noEmotion', 1200); ok(/Insufficient data/.test(await p.innerText('#ps-emo')) && /Belum ada emotion tag/.test(await p.innerText('#ps-emo')), 'noEmotion: guidance, no fake rows');
  ok((await p.locator('#ps-emo .ps-row:not(.hd)').count()) === 0, 'noEmotion: zero emotion rows'); await clean(p, 'noEmotion');

  // emotions, inclusive (default)
  p = await open('emo', 1200); let t = await p.innerText('#ps-emo');
  const fomo = p.locator('#ps-emo .ps-row:not(.hd)', { hasText: 'FOMO' }).first(); const ft = await fomo.innerText();
  // FOMO: 13 single-tag + 1 shared (FOMO,Anxious) = 14 trades, wins 5 => 35.7%
  ok(/14/.test(ft) && /35\.7%/.test(ft), 'emo/inclusive: FOMO 5W/14 = 35.7% (got ' + ft.replace(/\n/g, ' ') + ')');
  ok(/shared/.test(ft), 'emo/inclusive: shared flag on multi-tag row');
  ok(/\$-?[\d.]+|-\$[\d.]+/.test(ft) && /-\$/.test(ft), 'emo: net P/L shown with loss sign');
  const conf = await p.locator('#ps-emo .ps-row:not(.hd)', { hasText: 'Confident' }).first().innerText(); ok(/75\.0%/.test(conf), 'emo: Confident 9/12 = 75.0%');
  ok(/Insufficient data/.test(await p.locator('#ps-emo .ps-row:not(.hd)', { hasText: 'Revenge' }).first().innerText()), 'emo: Revenge (1 trade) = Insufficient data');
  ok(/Trade yang diberi tag FOMO memiliki win rate 36%/.test(t), 'emo: descriptive sentence present');
  await p.screenshot({ path: out + '/ps-desktop.png', fullPage: true }); await clean(p, 'emo');
  // exact mode excludes the 2-tag day
  await p.locator('#ps-root [data-mode="exact"]').click();
  ok(/13/.test(await p.locator('#ps-emo .ps-row:not(.hd)', { hasText: 'FOMO' }).first().innerText()) && !/Anxious/.test(await p.innerText('#ps-emo')), 'emo/exact: only single-tag days (FOMO=13, no Anxious row)');
  await p.locator('#ps-root [data-mode="inclusive"]').click();
  // cross: setup + session
  await p.locator('#ps-root [data-tab="setup"]').click(); t = await p.innerText('#ps-cross'); ok(/FOMO · (Breakout|Pullback)/.test(t), 'cross: Emotion × Setup rows');
  await p.locator('#ps-root [data-tab="session"]').click(); t = await p.innerText('#ps-cross'); ok(/Confident · London/.test(t), 'cross: Emotion × Session rows');
  await p.locator('#ps-root [data-tab="mistake"]').click(); t = await p.innerText('#ps-cross'); ok(/Belum ada Mistake Tag/.test(t), 'cross: Mistake Tag with no data => honest empty state'); await clean(p, 'cross');

  // mistake via tradeLog
  p = await open('mistake', 1200); await p.locator('#ps-root [data-tab="mistake"]').click(); t = await p.innerText('#ps-cross');
  ok(/FOMO · Early Entry/.test(t) && /11/.test(t), 'mistake: Emotion × Mistake Tag computed from tradeLog (11 trades)'); await clean(p, 'mistake');

  // score: loss+disciplined vs profit+FOMO; checklist incomplete; risk mixed
  const ls = { 'v21ck:2026-02-02': JSON.stringify(['d0', 'd1', 'd2', 'd3', 'd4', 'd5', 'd6']), 'v21riskok:2026-02-02': '1',
    'v21ck:2026-02-03': JSON.stringify(['d0', 'd1']), 'v21riskok:2026-02-03': '0' };
  p = await open('score', 1200, { ls }); t = await p.innerText('#ps-score');
  ok(/2 hari/.test(t), 'score: 2 scored days'); ok(/Entry Quality[\s\S]*No data/.test(t) && /Exit Management[\s\S]*No data/.test(t), 'score: Entry/Exit show "No data" (no fake numbers)');
  const days = await p.locator('#ps-score .ps-day:not(.hd)').allInnerTexts();
  const lossDay = days.find(d => d.includes('2026-02-02')), profDay = days.find(d => d.includes('2026-02-03'));
  const sc = d => +d.split('\n').map(s => s.trim()).filter(Boolean)[1];
  ok(sc(lossDay) === 100 && /-\$50\.00/.test(lossDay), 'score: loss day with full discipline = 100 (' + lossDay.replace(/\n/g, ' ') + ')');
  ok(sc(profDay) < 40 && /\$200\.00/.test(profDay), 'score: profit day with FOMO/Greedy, risk breach, 2/7 checklist = low (' + profDay.replace(/\n/g, ' ') + ')');
  ok(/Checklist Completion[\s\S]*64/.test(t) || /Checklist Completion/.test(t), 'score: checklist component shown');
  await p.screenshot({ path: out + '/ps-score-desktop.png', fullPage: true }); await clean(p, 'score');
  // custom checklist items change the denominator
  p = await open('score', 1200, { ls: Object.assign({}, ls, { v22ckitems: JSON.stringify([{ id: 'd0', t: 'A' }, { id: 'd1', t: 'B' }]) }) });
  ok(/Checklist Completion[\s\S]*100/.test(await p.innerText('#ps-score')), 'score: custom checklist (2 items) -> 2/2 = 100 on day 3');

  // no sources at all, emotion only (1 component) => Insufficient data
  p = await open('score', 1200); ok(/Insufficient data/.test(await p.innerText('#ps-score')) || /2 hari/.test(await p.innerText('#ps-score')), 'score: emotion-only days handled'); await clean(p, 'score-no-ls');

  // mobile + light
  p = await open('emo', 390, { ls }); await p.screenshot({ path: out + '/ps-mobile.png', fullPage: true }); await clean(p, 'mobile');
  ok(await p.locator('#ps-root .ps-row.hd').first().isHidden(), 'mobile: table header hidden, rows stacked');
  p = await open('score', 390, { ls, light: true }); await p.screenshot({ path: out + '/ps-score-mobile-light.png', fullPage: true }); await clean(p, 'mobile-light');
  p = await open('emo', 1200, { light: true }); await clean(p, 'light');

  // date filter + reset
  p = await open('emo', 1200); await p.fill('#ps-from', '2026-01-20'); await p.dispatchEvent('#ps-from', 'change');
  ok(/Confident/.test(await p.innerText('#ps-emo')), 'filter: Confident remains after from=2026-01-20'); await p.locator('#ps-root [data-reset]').click(); ok(/FOMO/.test(await p.innerText('#ps-emo')), 'filter: reset restores');
  await b.close();
  console.log(fails ? '\n' + fails + ' FAILED' : '\nALL PASSED'); process.exit(fails ? 1 : 0);
})();
