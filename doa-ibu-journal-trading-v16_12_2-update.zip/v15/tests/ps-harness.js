// Test harness only: synthetic data lives ONLY in tests/. The app never creates data.
const fs = require('fs'), path = require('path');
const root = path.join(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const css = html.match(/<style id="ps-style">[\s\S]*?<\/style>/)[0];
const js = html.match(/<script id="ps-script">[\s\S]*?<\/script>/)[0];
const stats = fs.readFileSync(path.join(root, 'v16-stats.js'), 'utf8');
function page(journals, light) {
  return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<style>body{margin:0;padding:16px;background:#0b0a07;color:#eee;font-family:system-ui,sans-serif}body.light{background:#f6f1e4;color:#27272a}
.glass{border:1px solid rgba(255,255,255,.16);background:rgba(255,255,255,.04)}body.light .glass{background:#fff;border-color:rgba(0,0,0,.15)}.hidden{display:none}</style>${css}</head>
<body class="${light ? 'light' : ''}"><div id="statistik-section"></div>
<script>var allJournals=${JSON.stringify(journals)};window.Money={format:function(v){return (v<0?'-':'')+'$'+Math.abs(v).toFixed(2)}};function renderStatistik(){}<\/script>
<script>${stats}<\/script>${js}<script>renderStatistik(allJournals)<\/script></body></html>`;
}
let n = 0;
function J(date, o) { return Object.assign({ id: 'j' + (++n), date, pl: 0, trades: 1, wins: 0, pair: 'EURUSD', session: 'London', tags: 'Breakout', bias: 'Long' }, o); }
const D = (i) => new Date(Date.UTC(2026, 0, 1 + i)).toISOString().slice(0, 10);
const sets = {
  empty: [],
  noEmotion: Array.from({ length: 12 }, (_, i) => J(D(i), { pl: i % 2 ? -10 : 15, wins: i % 2 ? 0 : 1 })),
  // 13 FOMO days (5 wins, 8 losses), 12 Confident days (9 wins, 3 losses), 1 two-tag day, 1 Revenge day (insufficient)
  emo: [].concat(
    Array.from({ length: 13 }, (_, i) => J(D(i), { emotions: ['FOMO'], pl: i < 5 ? 20 : -15, wins: i < 5 ? 1 : 0, tags: i % 2 ? 'Breakout' : 'Pullback', session: i % 2 ? 'London' : 'New York' })),
    Array.from({ length: 12 }, (_, i) => J(D(20 + i), { emotions: ['Confident'], pl: i < 9 ? 25 : -20, wins: i < 9 ? 1 : 0, tags: 'Breakout', session: 'London' })),
    [J(D(40), { emotions: ['FOMO', 'Anxious'], pl: -30, wins: 0 }), J(D(41), { emotions: ['Revenge'], pl: -10, wins: 0 })]),
  mistake: Array.from({ length: 11 }, (_, i) => J(D(i), { pl: i % 2 ? -10 : 15, wins: i % 2 ? 0 : 1, tradeLog: [{ pl: i % 2 ? -10 : 15, emotion: 'FOMO', mistake: 'Early Entry', setup: 'Breakout', session: 'London' }] })),
  // loss day with perfect behaviour vs profit day with poor behaviour (scores must NOT follow P/L)
  score: [J('2026-02-02', { pl: -50, wins: 0, emotions: ['Disciplined', 'Patient'] }), J('2026-02-03', { pl: 200, wins: 1, emotions: ['FOMO', 'Greedy'] })],
};
module.exports = { page, sets, D };
