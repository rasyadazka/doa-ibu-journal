// Test harness only: synthetic data lives ONLY in tests/. The app never creates data.
const fs = require('fs'), path = require('path');
const root = path.join(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const css = html.match(/<style id="v165-style">[\s\S]*?<\/style>/)[0];
const js = html.match(/<script id="v165-script">[\s\S]*?<\/script>/)[0];
const stats = fs.readFileSync(path.join(root, 'v16-stats.js'), 'utf8');
function page(journals, light, opt) {
  opt = opt || {};
  return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<style>body{margin:0;padding:16px;background:#0b0a07;color:#eee;font-family:system-ui,sans-serif}body.light{background:#f6f1e4;color:#27272a}
.glass{border:1px solid rgba(255,255,255,.16);background:rgba(255,255,255,.04)}body.light .glass{background:#fff;border-color:rgba(0,0,0,.15)}.hidden{display:none}main{max-width:1024px;margin:0 auto}</style>${css}</head>
<body class="${light ? 'light' : ''}"><main><div id="view-dashboard"><div id="dashboard-section"><div id="v165-dash"></div></div></div><div id="monthly-section" class="hidden"></div></main>
<script>var allJournals=${JSON.stringify(journals)};window.__opened=[];window.__reloads=0;
window.Money={format:function(v,o){return (v<0?'-':(o&&o.plus&&v>0?'+':''))+'$'+Math.abs(v).toFixed(2)},axis:function(v){return '$'+Math.round(v)}};
function editJournal(id){window.__opened.push(id)}
function loadJournals(){window.__reloads++}
function switchView(v){document.getElementById('view-dashboard').classList.toggle('hidden',v!=='dashboard');document.getElementById('monthly-section').classList.toggle('hidden',v!=='monthly');window.dispatchEvent(new CustomEvent('viewchange',{detail:{view:v}}))}<\/script>
<script>${stats}<\/script>${js}${opt.noLoad ? '' : '<script>window.dispatchEvent(new CustomEvent("journals-loaded"))<\/script>'}</body></html>`;
}
let n = 0;
function J(date, o) { return Object.assign({ id: 'j' + (++n), date, pl: 0, trades: 1, wins: 0, pair: 'EURUSD', session: 'London', tags: ['Breakout'], bias: 'Long', emotions: [] }, o); }
const iso = (y, m, d) => y + '-' + String(m).padStart(2, '0') + '-' + String(d).padStart(2, '0');
// Sept 2026: 14 trading days, mixed; Aug 2026: 5 days.  (legacy day-level docs, like the real app writes)
const sep = Array.from({ length: 14 }, (_, i) => {
  const win = i % 3 !== 1, pair = i % 2 ? 'XAUUSD' : 'EURUSD', setup = i % 4 === 0 ? 'Pullback' : 'Breakout';
  return J(iso(2026, 9, i + 1), { pl: win ? 25 + i : -(18 + i), trades: 2, wins: win ? 2 : 0, pair, tags: [setup], session: i % 2 ? 'New York' : 'London',
    emotions: i % 5 === 0 ? ['FOMO'] : i % 3 === 0 ? ['Disciplined', 'Patient'] : ['Confident'], bias: i % 2 ? 'Short' : 'Long' });
});
const aug = Array.from({ length: 5 }, (_, i) => J(iso(2026, 8, 3 + i), { pl: i % 2 ? -12 : 30, trades: 1, wins: i % 2 ? 0 : 1, pair: 'EURUSD', tags: ['Breakout'] }));
const tl = Array.from({ length: 12 }, (_, i) => J(iso(2026, 10, 1 + i), { pl: 0, trades: 1, wins: 0, tradeLog: [
  { pl: i % 3 ? 20 : -15, r: i % 3 ? 1.5 : -1, setup: 'Breakout', pair: 'EURUSD', session: 'London', direction: 'Long', emotion: i % 2 ? 'FOMO' : 'Confident', mistake: i % 3 ? undefined : 'Early Entry' },
  { pl: i % 2 ? 10 : -8, r: i % 2 ? 0.8 : -0.5, setup: 'Pullback', pair: 'XAUUSD', session: 'New York', direction: 'Short', emotion: 'Patient', mistake: i % 2 ? undefined : 'Early Entry' }] }));
const sets = {
  empty: [],
  rich: sep.concat(aug),
  tradeLog: tl.concat(aug),
  single: [J('2026-09-05', { pl: 40, trades: 3, wins: 2 })],
  allLoss: [J('2026-09-01', { pl: -10 }), J('2026-09-02', { pl: -20 })],
  allWin: [J('2026-09-01', { pl: 10, wins: 1 }), J('2026-09-02', { pl: 20, wins: 1 })],
  zero: [J('2026-09-01', { pl: 0 }), J('2026-09-02', { pl: 0 })],
  messy: [J('2026-09-01', { pl: 'abc', trades: 'x' }), { id: 'bad', date: 'not-a-date' }, null, J('2026-09-02', { pl: 15, wins: 1, tags: ['A', 'B'], pair: 'EURUSD, XAUUSD', session: 'London, New York', emotions: ['FOMO', 'Greedy'] })],
};
module.exports = { page, sets, J };
