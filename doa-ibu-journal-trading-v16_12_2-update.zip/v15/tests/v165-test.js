const { chromium } = require('/home/claude/.npm-global/lib/node_modules/playwright');
const { page: mk, sets, J } = require('./v165-harness');
const V = require('../v16-stats.js');
const fs = require('fs'); const out = '/home/claude/shots'; fs.mkdirSync(out, { recursive: true });
let fails = 0; const ok = (c, m) => { console.log((c ? 'PASS ' : 'FAIL ') + m); if (!c) fails++; };
const near = (a, b) => Math.abs(a - b) < 1e-6;

/* ---------- pure logic vs independent computation ---------- */
(function pure() {
  const raw = sets.rich, sepRows = raw.filter(j => j.date.startsWith('2026-09'));
  const u = V.normalize(raw), r = V.monthReview(u, '2026-09', { mm: v => '$' + v });
  const net = sepRows.reduce((a, j) => a + j.pl, 0), trades = sepRows.reduce((a, j) => a + j.trades, 0), wins = sepRows.reduce((a, j) => a + j.wins, 0);
  ok(near(r.stats.net, net) && r.stats.trades === trades && r.stats.wins === wins, 'pure: month net/trades/wins equal raw journal sums (' + net + '/' + trades + '/' + wins + ')');
  const gp = sepRows.filter(j => j.pl > 0).reduce((a, j) => a + j.pl, 0), gl = -sepRows.filter(j => j.pl < 0).reduce((a, j) => a + j.pl, 0);
  ok(near(r.stats.profitFactor, gp / gl), 'pure: profit factor = gross profit / gross loss');
  ok(near(r.stats.expectancy, net / trades), 'pure: expectancy = net / trades');
  let cum = 0, peak = 0, dd = 0; sepRows.slice().sort((a, b) => a.date < b.date ? -1 : 1).forEach(j => { cum += j.pl; peak = Math.max(peak, cum); dd = Math.max(dd, peak - cum); });
  ok(near(r.maxDrawdown, dd), 'pure: max drawdown from day equity (' + dd + ')');
  const best = sepRows.reduce((a, j) => j.pl > a.pl ? j : a), worst = sepRows.reduce((a, j) => j.pl < a.pl ? j : a);
  ok(r.bestDay.date === best.date && r.worstDay.date === worst.date, 'pure: best/worst day');
  ok(r.stats.avgR === null && r.topMistake === null, 'pure: no R / no mistake data => null (never invented)');
  const forbidden = /sebaiknya|disarankan|rekomendasi|anda harus|kamu harus|should|recommend|buy|sell|beli|jual|menyebabkan/i;
  ok(![].concat(r.well, r.improve).some(t => forbidden.test(t)), 'pure: observations contain no advice / causal wording');
  ok(V.monthReview(u, '2025-01') === null, 'pure: month without data => null');
  const t = V.monthReview(V.normalize(sets.tradeLog), '2026-10');
  ok(t.stats.avgR !== null && t.topMistake && t.topMistake.top[0].key === 'Early Entry', 'pure: trade-level data gives Average R and Most Common Mistake');
  const e = V.monthReview(V.normalize(sets.allWin), '2026-09'); ok(e.stats.profitFactor === null, 'pure: no loss => profit factor null (not Infinity)');
  const z = V.monthReview(V.normalize(sets.zero), '2026-09'); ok(z.stats.net === 0 && !Object.is(z.stats.net, -0), 'pure: zero P/L is 0 not -0');
  const m = V.monthReview(V.normalize(sets.messy), '2026-09'); ok(m && isFinite(m.stats.net), 'pure: malformed rows are skipped, finite result');
  ok(V.shiftMonth('2026-01', -1) === '2025-12' && V.shiftMonth('2026-12', 1) === '2027-01', 'pure: month shift across year boundary');
  const cal = V.calendarMonth(u, '2026-09'); ok(cal.cells.filter(Boolean).length === 30 && cal.tradedDays === 14, 'pure: calendar has 30 days, 14 traded; Monday-first padding=' + cal.cells.findIndex(Boolean));
})();

(async () => {
  const b = await chromium.launch();
  async function open(name, w, opts) {
    opts = opts || {};
    const ctx = await b.newContext({ viewport: { width: w, height: w < 700 ? 844 : 900 } });
    await ctx.route('http://t.local/**', r => r.fulfill({ contentType: 'text/html', body: mk(opts.data || sets[name], opts.light, opts) }));
    const p = await ctx.newPage(); const errs = []; p.on('pageerror', e => errs.push(e.message)); p.on('console', m => m.type() === 'error' && errs.push(m.text()));
    await p.goto('http://t.local/x'); await p.waitForSelector('#v165-dash .v5-title'); p.errs = errs; return p;
  }
  const clean = async (p, tag) => {
    const t = await p.evaluate(() => document.body.innerText);
    ok(!/NaN|undefined|Infinity|-0\.00|\[object|null/.test(t), tag + ': no NaN/undefined/Infinity/-0/null in text');
    ok(p.errs.length === 0, tag + ': no JS errors ' + p.errs.join('|'));
    ok(!(await p.evaluate(() => document.documentElement.scrollWidth > window.innerWidth + 1)), tag + ': no horizontal overflow');
    return t;
  };
  const kpis = p => p.$$eval('#v165-dash .v5-kpis .v5-kpi', els => els.map(e => ({ l: e.querySelector('.l').textContent, v: e.querySelector('.v').textContent })));

  // ---- dashboard on rich data, desktop dark
  let p = await open('rich', 1280);
  let k = await kpis(p);
  ok(k.map(x => x.l).join('|') === 'Net P/L|Win Rate|Profit Factor|Expectancy|Max Drawdown|Total Trades', 'dash: 6 KPI in required order');
  const all = sets.rich, net = all.reduce((a, j) => a + j.pl, 0), trades = all.reduce((a, j) => a + j.trades, 0), wins = all.reduce((a, j) => a + j.wins, 0);
  ok(k[0].v === (net < 0 ? '-' : '+') + '$' + Math.abs(net).toFixed(2), 'dash: Net P/L matches raw sum (' + k[0].v + ')');
  ok(k[1].v === (wins / trades * 100).toFixed(1) + '%', 'dash: Win rate matches raw (' + k[1].v + ')');
  ok(k[5].v === String(trades), 'dash: Total trades matches raw (' + k[5].v + ')');
  for (const h of ['Equity Curve', 'Monthly Calendar Heatmap', 'Setup Performance', 'Edge Finder Insights', 'Psychology Snapshot', 'Recent Trade Review']) ok(await p.locator('#v165-dash h3', { hasText: h }).count() === 1, 'dash: section "' + h + '" present');
  ok(await p.locator('#v5-eq svg path').count() >= 2, 'dash: equity curve SVG drawn');
  const cols = await p.$eval('.v5-grid', g => getComputedStyle(g).gridTemplateColumns.split(' ').length); ok(cols === 2, 'dash: desktop uses 2-column grid (' + cols + ')');
  await clean(p, 'dash desktop dark'); await p.screenshot({ path: out + '/v165-dash-desktop-dark.png', fullPage: true });
  // equity hover readout
  const box = await p.locator('#v5-hit').boundingBox(); await p.mouse.move(box.x + box.width / 2, box.y + 20);
  ok(/kumulatif/.test(await p.textContent('#v5-eq-read')), 'dash: equity hover shows date + cumulative');
  // calendar: current-month fallback -> latest month with data; nav & day detail
  ok(/Oktober 2026|September 2026/.test(await p.textContent('.v5-cal-nav .m')), 'calendar: opens on a month with data');
  const lab0 = await p.textContent('.v5-cal-nav .m'); await p.click('[data-cal="-1"]'); ok((await p.textContent('.v5-cal-nav .m')) !== lab0, 'calendar: prev month works');
  await p.click('[data-cal="1"]'); await p.click('button.v5-cell >> nth=0'); ok(await p.locator('.v5-day').count() === 1, 'calendar: clicking a day shows its detail');
  await p.click('.v5-day [data-open]'); ok((await p.evaluate(() => window.__opened)).length === 1, 'calendar: "Buka journal" calls editJournal');
  await p.click('.v5-cal-nav [data-cal="1"]'); await p.click('.v5-cal-nav [data-cal="1"]');
  ok(await p.locator('.v5-note', { hasText: 'Tidak ada trading pada bulan ini' }).count() === 1, 'calendar: empty month shows message');
  // recent
  ok(await p.locator('.v5-rt > div').count() === 5, 'recent: 5 latest trading days');
  await p.close();

  // ---- states
  p = await open('empty', 1280); ok(/Your Journey Starts Here/.test(await p.textContent('#v165-dash')) && await p.locator('[data-act="add"]').count() === 1, 'state: empty shows Your Journey Starts Here + add button'); await clean(p, 'empty'); await p.close();
  p = await open('empty', 390, { noLoad: true }); ok(await p.locator('#v165-dash [aria-busy="true"]').count() === 1, 'state: loading skeleton before data arrives');
  await p.evaluate(() => window.dispatchEvent(new CustomEvent('journals-error', { detail: { message: 'Gagal memuat data: offline' } })));
  ok(/Data belum bisa dimuat/.test(await p.textContent('#v165-dash')) && /offline/.test(await p.textContent('#v165-dash')), 'state: error shown with message');
  await p.click('[data-act="retry"]'); ok((await p.evaluate(() => window.__reloads)) === 1, 'state: retry calls loadJournals'); await p.close();
  for (const nm of ['single', 'allLoss', 'allWin', 'zero', 'messy', 'tradeLog']) { p = await open(nm, 390); await clean(p, 'dash mobile ' + nm); await p.close(); }
  p = await open('single', 1280); ok(/Baru 1 hari trading/.test(await p.textContent('#v165-dash')), 'state: single day => equity needs 2 days'); await p.close();

  // ---- mobile + light
  p = await open('rich', 390); await clean(p, 'dash mobile dark');
  const mcols = await p.$eval('.v5-grid', g => getComputedStyle(g).gridTemplateColumns.split(' ').length); ok(mcols === 1, 'dash: mobile stacks cards (' + mcols + ' col)');
  await p.screenshot({ path: out + '/v165-dash-mobile-dark.png', fullPage: true }); await p.close();
  p = await open('rich', 1280, { light: true }); await clean(p, 'dash desktop light'); await p.screenshot({ path: out + '/v165-dash-desktop-light.png', fullPage: true }); await p.close();
  p = await open('rich', 390, { light: true }); await clean(p, 'dash mobile light'); await p.screenshot({ path: out + '/v165-dash-mobile-light.png', fullPage: true }); await p.close();

  // ---- monthly review
  async function monthly(w, light, shot) {
    const q = await open('rich', w, { light }); await q.evaluate(() => switchView('monthly')); await q.waitForSelector('#monthly-section .v5-stats');
    const vals = await q.$$eval('#monthly-section .v5-stats .v5-kpi', els => els.map(e => [e.querySelector('.l').textContent, e.querySelector('.v').textContent, e.querySelector('.s').textContent]));
    return { q, vals, d: Object.fromEntries(vals.map(v => [v[0], v])) };
  }
  let M = await monthly(1280, false); p = M.q;
  ok(M.vals.map(v => v[0]).join('|') === 'Total Trades|Win Rate|Net P/L|Profit Factor|Expectancy|Average R|Max Drawdown|Best Day|Worst Day|Best Pair|Best Setup|Best Session|Most Common Mistake|Most Common Emotion', 'monthly: all 14 required metrics in order');
  ok(/Oktober 2026|September 2026/.test(await p.inputValue('#v5-month').then(v => p.textContent('#v5-month option[value="' + v + '"]'))), 'monthly: defaults to latest month with data');
  await p.selectOption('#v5-month', '2026-09'); await p.waitForSelector('#monthly-section .v5-stats');
  M.vals = await p.$$eval('#monthly-section .v5-stats .v5-kpi', els => els.map(e => [e.querySelector('.l').textContent, e.querySelector('.v').textContent, e.querySelector('.s').textContent])); M.d = Object.fromEntries(M.vals.map(v => [v[0], v]));
  const sepR = sets.rich.filter(j => j.date.startsWith('2026-09')), sNet = sepR.reduce((a, j) => a + j.pl, 0), sTr = sepR.reduce((a, j) => a + j.trades, 0), sW = sepR.reduce((a, j) => a + j.wins, 0);
  ok(M.d['Total Trades'][1] === String(sTr), 'monthly: Total Trades = ' + sTr);
  ok(M.d['Win Rate'][1] === (sW / sTr * 100).toFixed(1) + '%', 'monthly: Win Rate matches raw');
  ok(M.d['Net P/L'][1] === (sNet < 0 ? '-' : '+') + '$' + Math.abs(sNet).toFixed(2), 'monthly: Net P/L matches raw (' + M.d['Net P/L'][1] + ')');
  ok(/vs Agustus 2026/.test(M.d['Net P/L'][2]), 'monthly: compares with previous month when it exists');
  ok(M.d['Average R'][1] === 'N/A' && /Belum ada data R/.test(M.d['Average R'][2]), 'monthly: Average R shows N/A (no R data) instead of a made-up number');
  ok(M.d['Most Common Mistake'][1] === '—' && /Belum ada Mistake Tag/.test(M.d['Most Common Mistake'][2]), 'monthly: Most Common Mistake empty state');
  ok(M.d['Most Common Emotion'][1] !== '—', 'monthly: Most Common Emotion = ' + M.d['Most Common Emotion'][1] + ' (' + M.d['Most Common Emotion'][2] + ')');
  ok(await p.locator('#monthly-section h3', { hasText: 'What Went Well' }).count() === 1 && await p.locator('#monthly-section h3', { hasText: 'What Needs Improvement' }).count() === 1 && await p.locator('#monthly-section h3', { hasText: 'Focus for Next Month' }).count() === 1, 'monthly: Went Well / Needs Improvement / Focus sections');
  const txt = await p.textContent('#monthly-section'); ok(!/sebaiknya|disarankan|rekomendasi|kamu harus|should|recommend/i.test(txt.replace('Catatan di atas bersifat deskriptif, bukan rekomendasi trading.', '')), 'monthly: no trading recommendation wording');
  // change month -> numbers change
  await p.selectOption('#v5-month', '2026-08'); const augNet = sets.rich.filter(j => j.date.startsWith('2026-08')).reduce((a, j) => a + j.pl, 0);
  ok((await p.textContent('#monthly-section .v5-stats .v5-kpi:nth-child(3) .v')) === (augNet < 0 ? '-' : '+') + '$' + Math.abs(augNet).toFixed(2), 'monthly: switching to August recalculates Net P/L (' + augNet + ')');
  ok(/Belum ada bulan sebelumnya/.test(await p.textContent('#monthly-section .v5-stats .v5-kpi:nth-child(3) .s')), 'monthly: month without predecessor says so');
  // focus note
  await p.fill('#v5-focus', 'Tunggu konfirmasi sebelum entry'); await p.click('#v5-focus-save');
  ok((await p.evaluate(() => localStorage.getItem('v165focus:2026-08'))) === 'Tunggu konfirmasi sebelum entry', 'monthly: Focus note saved (local fallback; Firestore when logged in)');
  await p.selectOption('#v5-month', '2026-09'); ok((await p.inputValue('#v5-focus')) === '', 'monthly: Focus note is per month'); await p.selectOption('#v5-month', '2026-08'); ok((await p.inputValue('#v5-focus')) === 'Tunggu konfirmasi sebelum entry', 'monthly: Focus note restored for its month');
  await clean(p, 'monthly desktop dark'); await p.screenshot({ path: out + '/v165-monthly-desktop-dark.png', fullPage: true });
  // filter hook (Prompt 2 plugs in here): changing st.filters must change dashboard + monthly together
  await p.evaluate(() => { V165.state.filters = { pair: 'XAUUSD' }; V165.renderAll(); });
  await p.selectOption('#v5-month', '2026-09');
  const xauNet = sets.rich.filter(j => j.date.startsWith('2026-09') && j.pair === 'XAUUSD').reduce((a, j) => a + j.pl, 0);
  ok((await p.textContent('#monthly-section .v5-stats .v5-kpi:nth-child(3) .v')) === (xauNet < 0 ? '-' : '+') + '$' + Math.abs(xauNet).toFixed(2), 'filters: pair filter changes Monthly Review consistently (' + xauNet + ')');
  await p.evaluate(() => switchView('dashboard')); const dk = await kpis(p);
  const xAll = sets.rich.filter(j => j.pair === 'XAUUSD').reduce((a, j) => a + j.pl, 0); ok(dk[0].v === (xAll < 0 ? '-' : '+') + '$' + Math.abs(xAll).toFixed(2), 'filters: same filter changes Dashboard KPI (' + dk[0].v + ')');
  await p.evaluate(() => { V165.state.filters = { pair: 'NOPE' }; V165.renderAll(); }); ok(/Tidak ada data pada filter ini/.test(await p.textContent('#v165-dash')), 'filters: no-match state on dashboard');
  await p.close();
  M = await monthly(390, false); await clean(M.q, 'monthly mobile dark'); await M.q.screenshot({ path: out + '/v165-monthly-mobile-dark.png', fullPage: true }); await M.q.close();
  M = await monthly(1280, true); await clean(M.q, 'monthly desktop light'); await M.q.screenshot({ path: out + '/v165-monthly-desktop-light.png', fullPage: true }); await M.q.close();
  M = await monthly(390, true); await clean(M.q, 'monthly mobile light'); await M.q.close();
  for (const nm of ['single', 'allLoss', 'allWin', 'zero', 'messy', 'tradeLog']) { const q = await open(nm, 390); await q.evaluate(() => switchView('monthly')); await q.waitForSelector('#monthly-section .v5-stats'); await clean(q, 'monthly mobile ' + nm); await q.close(); }
  const q = await open('tradeLog', 1280); await q.evaluate(() => switchView('monthly')); await q.waitForSelector('#monthly-section .v5-stats');
  const tv = await q.$$eval('#monthly-section .v5-stats .v5-kpi', els => Object.fromEntries(els.map(e => [e.querySelector('.l').textContent, e.querySelector('.v').textContent])));
  ok(/R$/.test(tv['Average R']) && tv['Most Common Mistake'] === 'Early Entry', 'monthly: trade-level data fills Average R (' + tv['Average R'] + ') and Most Common Mistake'); await q.close();
  await b.close();
  console.log(fails ? '\n' + fails + ' FAILED' : '\nALL PASSED'); process.exit(fails ? 1 : 0);
})();
