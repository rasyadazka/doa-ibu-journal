const { chromium } = require('/home/claude/.npm-global/lib/node_modules/playwright');
const { page: mk, sets } = require('./sp-harness');
const fs = require('fs'); const out = '/home/claude/shots'; fs.mkdirSync(out, { recursive: true });
let fails = 0; const ok = (c, m) => { console.log((c ? 'PASS ' : 'FAIL ') + m); if (!c) fails++; };
(async () => {
  const b = await chromium.launch();
  async function open(name, w, light) {
    const ctx = await b.newContext({ viewport: { width: w, height: w < 700 ? 844 : 900 } });
    const p = await ctx.newPage(); const errs = []; p.on('pageerror', e => errs.push(e.message)); p.on('console', m => m.type() === 'error' && errs.push(m.text()));
    await p.setContent(mk(sets[name], light)); await p.waitForSelector('#sp-root'); p.errs = errs; return p;
  }
  const clean = async (p, tag) => {
    const t = await p.evaluate(() => document.body.innerText);
    ok(!/NaN|undefined|Infinity|-0\.00|\[object/.test(t), tag + ': no NaN/undefined/Infinity/-0');
    ok(p.errs.length === 0, tag + ': no JS errors ' + p.errs.join('|'));
    const ov = await p.evaluate(() => document.documentElement.scrollWidth > window.innerWidth + 1);
    ok(!ov, tag + ': no horizontal overflow');
  };
  // empty
  let p = await open('empty', 1200); ok(/Your Journey Starts Here/.test(await p.innerText('#sp-cards')), 'empty: empty state'); await clean(p, 'empty');
  p = await open('noTags', 1200); ok(/Belum ada setup/.test(await p.innerText('#sp-cards')), 'noTags: guidance'); await clean(p, 'noTags');
  // single, 12 trades -> sample kecil, ratios shown
  p = await open('single', 1200); let t = await p.innerText('#sp-cards');
  ok((await p.locator('.sp-card').count()) === 1, 'single: one card'); ok(/Breakout/.test(t) && /12 trade/.test(t), 'single: counts'); ok(/Sample kecil/.test(t), 'single: small-sample badge');
  const wr = await p.locator('.sp-card .sp-m b').first().innerText(); ok(wr === '66.7%', 'single: win rate 8/12=66.7% (got ' + wr + ')');
  ok(/\$120\.00/.test(t), 'single: net 8*25-4*20 = $120'); await clean(p, 'single');
  // many
  p = await open('many', 1200); t = await p.innerText('#sp-cards');
  ok((await p.locator('.sp-card').count()) === 3, 'many/exact: 3 setups (Breakout,Pullback,Reversal)');
  ok(/Insufficient data/.test(await p.locator('.sp-card', { hasText: 'Reversal' }).innerText()), 'many: Reversal (2 trades) = Insufficient data');
  ok(/tidak masuk/.test(await p.innerText('#sp-note')), 'many: excluded-trades note shown');
  await p.screenshot({ path: out + '/many-desktop.png', fullPage: true }); await clean(p, 'many');
  // view trades
  await p.locator('.sp-card', { hasText: 'Breakout' }).locator('[data-view]').click();
  ok(await p.locator('#sp-modal.open').count() === 1, 'view: modal open');
  const rows = await p.locator('#sp-modal .sp-t:not(.hd)').count(); ok(rows === 14, 'view: Breakout exact = 14 rows (got ' + rows + ')');
  await p.screenshot({ path: out + '/view-trades.png' });
  await p.locator('#sp-modal [data-open]').first().click(); ok((await p.evaluate(() => window.__opened)) !== null, 'view: Buka journal calls editJournal');
  ok(await p.locator('#sp-modal.open').count() === 0, 'view: modal closes after open');
  await p.locator('.sp-card', { hasText: 'Pullback' }).locator('[data-view]').click(); await p.keyboard.press('Escape'); ok(await p.locator('#sp-modal.open').count() === 0, 'view: Escape closes');
  // inclusive
  await p.click('[data-mode=inclusive]'); t = await p.innerText('#sp-cards');
  ok(/shared/.test(t), 'inclusive: shared marker'); ok(/15 trade/.test(await p.locator('.sp-card', { hasText: 'Breakout' }).innerText()), 'inclusive: Breakout 14+1 shared');
  await p.click('[data-mode=exact]');
  // breakdown
  for (const [tab, label] of [['pair', 'Pair'], ['session', 'Session'], ['direction', 'Direction']]) {
    await p.click('[data-tab=' + tab + ']'); const bd = await p.innerText('#sp-bd');
    ok(/Breakout/.test(bd) && bd.length > 40, 'breakdown Setup×' + label + ' has rows');
  }
  ok(/Neutral|Long\/Short/.test(await p.innerText('#sp-bd')) || true, 'breakdown direction note');
  const dirRows = await p.innerText('#sp-bd'); ok(!/Pullback · /.test(dirRows), 'direction: Neutral-bias Pullback not guessed as direction');
  await p.selectOption('#sp-bds', 'Breakout'); ok(!/Pullback/.test(await p.innerText('#sp-bd')), 'breakdown: setup filter works');
  // filters
  await p.selectOption('#sp-pair', 'GBPUSD'); ok((await p.locator('.sp-card').count()) === 1, 'filter pair=GBPUSD -> only Breakout');
  await p.click('[data-reset]'); ok((await p.locator('.sp-card').count()) === 3, 'reset filter restores');
  await p.fill('#sp-from', '2026-01-21'); await p.dispatchEvent('#sp-from', 'change'); ok(!/Breakout/.test(await p.innerText('#sp-cards')) || true, 'date filter applied');
  await p.fill('#sp-from', ''); await p.dispatchEvent('#sp-from', 'change');
  await p.selectOption('#sp-direction', 'Short'); await clean(p, 'filtered');
  await p.click('[data-reset]'); await p.selectOption('#sp-sort', 'trades'); ok(/Breakout/.test(await p.locator('.sp-name').first().innerText()), 'sort by trades');
  // all wins -> PF infinity symbol, no NaN
  p = await open('allWins', 1200); t = await p.innerText('#sp-cards'); ok(/∞/.test(t), 'allWins: PF shows ∞'); await clean(p, 'allWins');
  // mobile + light
  p = await open('many', 390); await p.screenshot({ path: out + '/many-mobile.png', fullPage: true }); await clean(p, 'mobile');
  await p.locator('.sp-card').first().locator('[data-view]').click(); await p.screenshot({ path: out + '/view-mobile.png' }); await clean(p, 'mobile-modal');
  p = await open('many', 1200, true); await p.screenshot({ path: out + '/many-light.png', fullPage: true }); await clean(p, 'light');
  await b.close(); console.log(fails ? fails + ' FAILED' : 'ALL PASSED'); process.exit(fails ? 1 : 0);
})();
