// V16.5 Prompt 2 — Global Filter tests. Synthetic data lives ONLY here (tests/), never in the app.
const { chromium } = require('/home/claude/.npm-global/lib/node_modules/playwright');
const { page: mk, sets, J } = require('./v165-harness');
const V = require('../v16-stats.js');
const fs = require('fs'), path = require('path');
const out = '/home/claude/shots'; fs.mkdirSync(out, { recursive: true });
let fails = 0; const ok = (c, m) => { console.log((c ? 'PASS ' : 'FAIL ') + m); if (!c) fails++; };
const near = (a, b) => Math.abs(a - b) < 1e-6;
const BAD = /NaN|undefined|Infinity|-0(?![\d.])|\bnull\b/;

/* ---------- pure: filter semantics vs independent computation ---------- */
(function pure() {
  const raw = sets.rich, u = V.normalize(raw);
  const exp = (fn) => { const r = raw.filter(fn); return { n: r.reduce((a, j) => a + j.trades, 0), net: r.reduce((a, j) => a + j.pl, 0), days: r.length }; };
  const chk = (f, fn, label) => { const a = V.applyFilters(u, f, { inclusive: true }), s = V.calc(a), e = exp(fn); ok(s.trades === e.n && near(s.net, e.net) && a.length === e.days, `pure: ${label} -> ${e.days} hari / ${e.n} trade / net ${e.net}`); };
  chk({ pair: 'XAUUSD' }, j => j.pair === 'XAUUSD', 'pair');
  chk({ session: 'London' }, j => j.session === 'London', 'session');
  chk({ setup: 'Pullback' }, j => j.tags.includes('Pullback'), 'setup');
  chk({ tag: 'Breakout' }, j => j.tags.includes('Breakout'), 'tags');
  chk({ direction: 'Short' }, j => j.bias === 'Short', 'direction');
  chk({ result: 'win' }, j => j.pl > 0, 'result=win');
  chk({ result: 'loss' }, j => j.pl < 0, 'result=loss');
  chk({ emotion: 'FOMO' }, j => j.emotions.length === 1 && j.emotions[0] === 'FOMO', 'emotion (single)');
  chk({ from: '2026-09-05', to: '2026-09-10' }, j => j.date >= '2026-09-05' && j.date <= '2026-09-10', 'date range');
  chk({ pair: 'EURUSD', result: 'win', direction: 'Long', from: '2026-09-01', to: '2026-09-30' }, j => j.pair === 'EURUSD' && j.pl > 0 && j.bias === 'Long' && j.date.startsWith('2026-09'), 'combined (AND)');
  ok(V.applyFilters(u, {}, { inclusive: true }).length === u.length, 'pure: empty filter keeps everything');
  const multi = V.normalize(sets.messy), ex = V.applyFilters(multi, { pair: 'EURUSD' }), inc = V.applyFilters(multi, { pair: 'EURUSD' }, { inclusive: true });
  ok(ex.length === 1 && inc.length === 2 && inc.ambiguous === 1, 'pure: multi-pair journal is matched only in inclusive mode and counted as ambiguous');
  const o = V.filterOptions(u); ok(o.pair.join() === 'EURUSD,XAUUSD' && o.session.join() === 'London,New York' && o.setup.join() === 'Breakout,Pullback' && o.emotion.indexOf('FOMO') >= 0, 'pure: filterOptions come from data only: ' + JSON.stringify(o.pair) + JSON.stringify(o.session));
  ok(V.filterOptions([]).pair.length === 0, 'pure: no data -> no options');
})();

(async () => {
  const b = await chromium.launch();
  async function open(name, w, opts) {
    opts = opts || {};
    const ctx = await b.newContext({ viewport: { width: w, height: w < 700 ? 844 : 900 } });
    await ctx.route('http://t.local/**', r => r.fulfill({ contentType: 'text/html', body: mk(opts.data || sets[name], opts.light, opts) }));
    const p = await ctx.newPage(); const errs = []; p.on('pageerror', e => errs.push(e.message)); p.on('console', m => m.type() === 'error' && errs.push(m.text()));
    await p.goto('http://t.local/'); await p.waitForTimeout(250);
    return { p, ctx, errs };
  }
  const txt = (p, sel) => p.$eval(sel, e => e.textContent);
  const kpis = (p) => p.$$eval('#v165-dash .v5-kpis .v5-kpi .v', els => els.map(e => e.textContent));
  const num = (s) => parseFloat(String(s).replace(/[^0-9.\-]/g, ''));
  const open_ = async (p) => { if ((await p.getAttribute('#v165-dash [data-ftoggle]', 'aria-expanded')) !== 'true') await p.click('#v165-dash [data-ftoggle]'); };

  /* ---------- desktop: bar, filtering, consistency, clear ---------- */
  {
    const { p, ctx, errs } = await open('rich', 1280);
    ok(await p.$('#v165-dash .v5-fbar') !== null, 'ui: filter bar rendered on Dashboard');
    ok(await p.$('#v165-dash .v5-fgrid') === null, 'ui: filter fields collapsed by default (dashboard stays light)');
    ok(await p.$eval('#v165-dash [data-fclear]', e => e.disabled), 'ui: Clear All Filters disabled when nothing is active');
    const base = await kpis(p);
    await open_(p);
    const labels = await p.$$eval('#v165-dash .v5-fld > span', els => els.map(e => e.textContent));
    ok(labels.join('|') === 'Dari tanggal|Sampai tanggal|Pair|Session|Setup|Direction|Result|Tags|Emotion', 'ui: all 9 filters present: ' + labels.join(', '));
    await p.focus('#v165-dash [data-f="pair"]'); await p.selectOption('#v165-dash [data-f="pair"]', 'XAUUSD'); await p.waitForTimeout(100);
    const focusKept = await p.evaluate(() => document.activeElement && document.activeElement.getAttribute('data-f'));
    ok(focusKept === 'pair', 'ui: keyboard focus stays on the field after filtering');
    const raw = sets.rich.filter(j => j.pair === 'XAUUSD'), rn = raw.reduce((a, j) => a + j.trades, 0), rpl = raw.reduce((a, j) => a + j.pl, 0);
    let k = await kpis(p);
    ok(num(k[5]) === rn && near(Math.abs(num(k[0])), Math.abs(rpl)), `dashboard: pair=XAUUSD -> trades ${k[5]} (exp ${rn}), net ${k[0]} (exp ${rpl})`);
    ok((await txt(p, '#v165-dash .v5-fsum')).replace(/\s+/g, ' ').includes('Menampilkan ' + rn + ' dari'), 'ui: summary says how many trades are shown: ' + (await txt(p, '#v165-dash .v5-fsum')));
    ok(await p.$('#v165-dash .v5-fchip') !== null && !(await p.$eval('#v165-dash [data-fclear]', e => e.disabled)), 'ui: active chip shown and Clear enabled');
    ok((await txt(p, '#v165-dash .v5-fcount')) === '1', 'ui: active filter count badge = 1');
    await p.selectOption('#v165-dash [data-f="result"]', 'win'); await p.selectOption('#v165-dash [data-f="direction"]', 'Short'); await p.waitForTimeout(100);
    const r2 = sets.rich.filter(j => j.pair === 'XAUUSD' && j.pl > 0 && j.bias === 'Short'); k = await kpis(p);
    ok(num(k[5]) === r2.reduce((a, j) => a + j.trades, 0) && k[0].replace(/[^0-9.]/g, '') === r2.reduce((a, j) => a + j.pl, 0).toFixed(2), `dashboard: pair+result+direction (AND) -> ${k[5]} trades, ${k[0]}`);
    /* Monthly Review follows the same filters */
    await p.evaluate(() => switchView('monthly')); await p.waitForSelector('#monthly-section .v5-stats'); await p.waitForTimeout(150);
    ok(await p.$('#monthly-section .v5-fbar') !== null && (await txt(p, '#monthly-section .v5-fcount')) === '3', 'monthly: same filter bar with the same 3 active filters');
    const mk_ = await p.$$eval('#monthly-section .v5-stats .v5-kpi', els => els.map(e => [e.querySelector('.l').textContent, e.querySelector('.v').textContent]));
    const month = await p.$eval('#v5-month', e => e.value), rm = r2.filter(j => j.date.startsWith(month));
    const mt = mk_.find(x => x[0] === 'Total Trades')[1], mn = mk_.find(x => x[0] === 'Net P/L')[1];
    ok(num(mt) === rm.reduce((a, j) => a + j.trades, 0) && mn.replace(/[^0-9.]/g, '') === rm.reduce((a, j) => a + j.pl, 0).toFixed(2), `monthly: ${month} with 3 filters -> ${mt} trades, ${mn}`);
    ok(!BAD.test(await p.$eval('#monthly-section', e => e.innerText)), 'monthly: no NaN/undefined/Infinity with filters');
    /* remove one chip from Monthly, Dashboard follows */
    await p.click('#monthly-section [data-fx="result"]'); await p.waitForTimeout(100);
    ok((await txt(p, '#monthly-section .v5-fcount')) === '2', 'monthly: removing a chip drops the filter');
    await p.evaluate(() => switchView('dashboard')); await p.waitForTimeout(150);
    ok((await txt(p, '#v165-dash .v5-fcount')) === '2', 'sync: Dashboard sees the chip removed in Monthly Review');
    /* Clear All */
    await p.click('#v165-dash [data-fclear]'); await p.waitForTimeout(100);
    ok(JSON.stringify(await kpis(p)) === JSON.stringify(base), 'Clear All Filters restores the exact original KPIs');
    ok(await p.$('#v165-dash .v5-fchip') === null && await p.$eval('#v165-dash [data-fclear]', e => e.disabled), 'Clear All Filters removes chips and disables itself');
    ok(await p.evaluate(() => Object.keys(window.V165.state.filters).length === 0), 'Clear All Filters empties filter state');
    /* no match + recovery */
    await p.evaluate(() => { window.V165.setFilter('from', '2030-01-01'); }); await p.waitForTimeout(100);
    ok(/Tidak ada data pada filter ini/.test(await txt(p, '#v165-dash')) && await p.$('#v165-dash .v5-empty [data-fclear]') !== null, 'empty state with Clear button when filters match nothing');
    ok(await p.$('#v165-dash .v5-fbar') !== null, 'filter bar stays visible in the no-match state');
    await p.click('#v165-dash .v5-empty [data-fclear]'); await p.waitForTimeout(100);
    ok((await kpis(p)).length === 6, 'recovered from no-match with Clear All Filters');
    /* date order warning */
    await open_(p); await p.fill('#v165-dash [data-f="from"]', '2026-09-20'); await p.dispatchEvent('#v165-dash [data-f="from"]', 'change'); await p.waitForTimeout(100);
    await p.fill('#v165-dash [data-f="to"]', '2026-09-10'); await p.dispatchEvent('#v165-dash [data-f="to"]', 'change'); await p.waitForTimeout(100);
    ok(await p.$('#v165-dash .v5-fwarn') !== null, 'date range in wrong order shows a warning instead of silently showing nothing');
    await p.click('#v165-dash [data-fclear]'); await p.waitForTimeout(80);
    await p.screenshot({ path: out + '/v165-filter-desktop.png', fullPage: true });
    ok(errs.length === 0, 'no JS errors (desktop) ' + errs.join('; ')); await ctx.close();
  }

  /* ---------- mobile ---------- */
  for (const light of [false, true]) {
    const { p, ctx, errs } = await open('rich', 375, { light });
    await open_(p); await p.selectOption('#v165-dash [data-f="session"]', 'London'); await p.waitForTimeout(100); await open_(p);
    const cols = await p.$eval('#v165-dash .v5-fgrid', e => getComputedStyle(e).gridTemplateColumns.split(' ').length);
    const ov = await p.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
    ok(cols === 2 && ov <= 1, `mobile${light ? ' light' : ''}: filter grid 2 columns, no horizontal overflow (overflow ${ov}px)`);
    const small = await p.$$eval('#v165-dash .v5-fbar select, #v165-dash .v5-fbar input, #v165-dash .v5-fbar button', els => els.filter(e => e.offsetParent && e.getBoundingClientRect().height < 40).length);
    ok(small === 0, 'mobile: filter controls are at least 40px tall (touch friendly)');
    ok(!BAD.test(await p.$eval('#v165-dash', e => e.innerText)), 'mobile: no NaN/undefined/Infinity with filter on');
    if (!light) await p.screenshot({ path: out + '/v165-filter-mobile.png', fullPage: true });
    ok(errs.length === 0, 'no JS errors (mobile) ' + errs.join('; ')); await ctx.close();
  }

  /* ---------- states: empty / loading / error / messy / trade-level ---------- */
  {
    let t = await open('empty', 1024);
    ok(/Your Journey Starts Here/.test(await txt(t.p, '#v165-dash')) && await t.p.$('#v165-dash .v5-fbar') === null, 'state: empty journal -> empty state, no pointless filter bar'); await t.ctx.close();
    t = await open('rich', 1024, { noLoad: true, data: [] });
    ok(await t.p.$('#v165-dash [aria-busy="true"]') !== null, 'state: loading skeleton while data is not ready');
    await t.p.evaluate(() => window.dispatchEvent(new CustomEvent('journals-error', { detail: { message: 'Gagal memuat data: uji' } }))); await t.p.waitForTimeout(100);
    ok(await t.p.$('#v165-dash [role="alert"]') !== null && /Coba lagi/.test(await txt(t.p, '#v165-dash')) && await t.p.$('#v165-dash .v5-fbar') === null, 'state: error with retry button, no filter bar');
    await t.p.click('#v165-dash [data-act="retry"]'); await t.p.waitForTimeout(100);
    ok(await t.p.evaluate(() => window.__reloads) === 1, 'state: retry calls loadJournals'); await t.ctx.close();
    t = await open('messy', 1024); await open_(t.p);
    await t.p.selectOption('#v165-dash [data-f="pair"]', 'EURUSD'); await t.p.waitForTimeout(100);
    ok(/dua pair|beberapa nilai/.test(await txt(t.p, '#v165-dash .v5-fbar')) && !BAD.test(await t.p.$eval('#v165-dash', e => e.innerText)), 'messy: multi-value journal is included with an honest note, no NaN/undefined'); await t.ctx.close();
    t = await open('tradeLog', 1024); await open_(t.p);
    await t.p.selectOption('#v165-dash [data-f="emotion"]', 'FOMO'); await t.p.waitForTimeout(100);
    const tl = V.applyFilters(V.normalize(sets.tradeLog), { emotion: 'FOMO' }, { inclusive: true }), s = V.calc(tl);
    ok(num((await kpis(t.p))[5]) === s.trades, 'trade-level data: emotion filter works per trade (' + s.trades + ' trades)');
    await t.p.selectOption('#v165-dash [data-f="result"]', 'loss'); await t.p.waitForTimeout(100);
    const tl2 = V.applyFilters(V.normalize(sets.tradeLog), { emotion: 'FOMO', result: 'loss' }, { inclusive: true });
    ok(num((await kpis(t.p))[5]) === V.calc(tl2).trades && tl2.every(x => x.pl < 0), 'trade-level data: result=loss keeps only losing trades'); await t.ctx.close();
  }
  await b.close();

  /* ---------- real app: two-way sync with the V15 Journal filter ---------- */
  const src = fs.readFileSync(path.join(__dirname, 'v165-app-test.js'), 'utf8');
  const head = src.slice(src.indexOf('const DIRS'), src.indexOf('(async () => {'));
  const { run, DIRS } = new Function('chromium', 'sets', 'fs', 'path', 'out', '__dirname', head.replace("old: '/home/claude/orig/v15'", "old: ''") + '; return { run, DIRS };')(chromium, sets, fs, path, out, __dirname);
  const { p, b: b2, errs } = await run('new', sets.rich.map(j => Object.assign({}, j)), 1280);
  await p.click('#nav-dashboard'); await p.waitForTimeout(200);
  const total = await p.evaluate(() => document.getElementById('journal-count').textContent);
  await p.click('#btn-filter-toggle'); await p.selectOption('#filter-pair', 'XAUUSD'); await p.waitForTimeout(150);
  const st1 = await p.evaluate(() => ({ f: window.V165.state.filters, cnt: document.getElementById('journal-count').textContent }));
  ok(st1.f.pair === 'XAUUSD', 'sync: Journal list filter (pair) -> Global filter ' + JSON.stringify(st1.f));
  ok(await p.$('#v165-dash [data-fx="pair"]') !== null, 'sync: Dashboard shows the pair chip after filtering the Journal list');
  await p.selectOption('#filter-bias', 'Short'); await p.waitForTimeout(100);
  ok(await p.evaluate(() => window.V165.state.filters.direction) === 'Short', 'sync: Journal "Arah" -> Global Direction');
  await p.selectOption('#filter-bias', 'Neutral'); await p.waitForTimeout(100);
  ok(await p.evaluate(() => window.V165.state.filters.direction) === undefined, 'sync: "Neutral" has no Dashboard equivalent and is not forced into Direction');
  await p.selectOption('#filter-bias', ''); await p.waitForTimeout(50);
  await p.evaluate(() => { window.V165.setFilter('session', 'London'); window.V165.setFilter('from', '2026-09-03'); window.V165.setFilter('setup', 'Breakout'); window.V165.setFilter('emotion', 'FOMO'); });
  await p.waitForTimeout(150);
  const v15 = await p.evaluate(() => ({ s: document.getElementById('filter-session').value, d: document.getElementById('filter-date-start').value, p: document.getElementById('filter-pair').value, cnt: document.getElementById('journal-count').textContent }));
  ok(v15.s === 'London' && v15.d === '2026-09-03' && v15.p === 'XAUUSD', 'sync: Global filter -> Journal list inputs ' + JSON.stringify(v15));
  const exp = sets.rich.filter(j => j.pair === 'XAUUSD' && j.session === 'London' && j.date >= '2026-09-03').length;
  ok(v15.cnt.startsWith(exp + ' / ') || (exp === sets.rich.length && v15.cnt.startsWith(String(exp))), `sync: Journal list count follows (${v15.cnt}, expected ${exp})`);
  ok(await p.evaluate(() => window.V165.state.filters.setup === 'Breakout' && window.V165.state.filters.emotion === 'FOMO'), 'Setup/Emotion are Dashboard-only filters and stay in global state');
  await p.click('#v165-dash [data-fclear]'); await p.waitForTimeout(150);
  const v15b = await p.evaluate(() => ({ v: ['filter-pair', 'filter-session', 'filter-date-start', 'filter-bias', 'filter-tag'].map(i => document.getElementById(i).value).join('|'), cnt: document.getElementById('journal-count').textContent }));
  ok(v15b.v === '||||' && v15b.cnt === total, 'sync: Clear All Filters also clears the Journal list filter (' + v15b.cnt + ')');
  await p.selectOption('#filter-pair', 'EURUSD'); await p.waitForTimeout(80); await p.click('#btn-filter-reset'); await p.waitForTimeout(120);
  ok(await p.evaluate(() => Object.keys(window.V165.state.filters).length) === 0, 'sync: V15 "Reset Filter" clears the mirrored global filters');
  const rows = await p.evaluate(() => buildExportRows().length); ok(rows === sets.rich.length, 'export still works and follows the Journal list (' + rows + ' rows)');
  const real = errs.filter(e => !/hasPendingWrites/.test(e)); ok(real.length === 0, 'real app: no new JS errors ' + real.join('; '));
  await b2.close();
  console.log(fails ? '\n' + fails + ' FAILED' : '\nALL PASSED'); process.exit(fails ? 1 : 0);
})();
