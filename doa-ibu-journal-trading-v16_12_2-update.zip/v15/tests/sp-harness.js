// Test harness only: data below is synthetic and lives ONLY in tests/. The app itself never creates data.
const fs = require('fs'), path = require('path');
const root = path.join(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const css = html.match(/<style id="sp-style">[\s\S]*?<\/style>/)[0];
const js = html.match(/<script id="sp-script">[\s\S]*?<\/script>/)[0];
const stats = fs.readFileSync(path.join(root, 'v16-stats.js'), 'utf8');
function page(journals, light) {
  return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<style>body{margin:0;padding:16px;background:#0b0a07;color:#eee;font-family:system-ui,sans-serif}body.light{background:#f6f1e4;color:#27272a}
.glass{border:1px solid rgba(255,255,255,.16);background:rgba(255,255,255,.04)}body.light .glass{background:#fff;border-color:rgba(0,0,0,.15)}.hidden{display:none}</style>${css}</head>
<body class="${light ? 'light' : ''}"><div id="statistik-section"></div>
<script>var allJournals=${JSON.stringify(journals)};window.Money={format:function(v){return (v<0?'-':'')+'$'+Math.abs(v).toFixed(2)}};window.__opened=null;function editJournal(id){window.__opened=id}function renderStatistik(){}<\/script>
<script>${stats}<\/script>${js}<script>renderStatistik(allJournals)<\/script></body></html>`;
}
let n = 0;
function J(date, o) { return Object.assign({ id: 'j' + (++n), date, pl: 0, trades: 1, wins: 0, pair: 'EURUSD', session: 'London', tags: 'Breakout', bias: 'Long' }, o); }
const D = (i) => { const d = new Date(Date.UTC(2026, 0, 1 + i)); return d.toISOString().slice(0, 10); };
const sets = {
  empty: [],
  noTags: [J(D(0), { tags: '', pl: 10, wins: 1 })],
  single: Array.from({ length: 12 }, (_, i) => J(D(i), { pl: i % 3 ? 25 : -20, wins: i % 3 ? 1 : 0, trades: 1 })),
  many: [].concat(
    Array.from({ length: 14 }, (_, i) => J(D(i), { tags: 'Breakout', pl: i % 3 ? 30 : -20, wins: i % 3 ? 1 : 0, pair: i % 2 ? 'EURUSD' : 'GBPUSD', session: i % 2 ? 'London' : 'New York', bias: i % 4 ? 'Long' : 'Short' })),
    Array.from({ length: 11 }, (_, i) => J(D(20 + i), { tags: 'Pullback', pl: i % 2 ? -15 : 22, wins: i % 2 ? 0 : 1, pair: 'XAUUSD', session: 'London', bias: 'Neutral' })),
    [J(D(40), { tags: 'Reversal', pl: -12, wins: 0 }), J(D(41), { tags: 'Reversal', pl: 40, wins: 1 }),
     J(D(42), { tags: ['Breakout', 'Pullback'], pl: 18, wins: 1, pair: ['EURUSD', 'GBPUSD'], session: 'London, New York' }),
     J(D(43), { tags: '', pl: 5, wins: 1 })]),
  allWins: Array.from({ length: 12 }, (_, i) => J(D(i), { tags: 'Scalp', pl: 10, wins: 1 })),
};
module.exports = { page, sets };
