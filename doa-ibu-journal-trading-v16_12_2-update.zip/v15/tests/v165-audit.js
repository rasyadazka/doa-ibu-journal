// Audit seluruh V16 di aplikasi asli: NaN/undefined/Infinity, overflow horizontal, font kecil. Data sintetis hanya di tests/.
const { chromium } = require('/home/claude/.npm-global/lib/node_modules/playwright');
const { sets } = require('./v165-harness');
const fs = require('fs'), path = require('path');
const out = '/home/claude/shots';
const src = fs.readFileSync(path.join(__dirname, 'v165-app-test.js'), 'utf8');
const head = src.slice(src.indexOf('const DIRS'), src.indexOf('(async () => {'));
const { run } = new Function('chromium', 'sets', 'fs', 'path', 'out', '__dirname', head.replace("old: '/home/claude/orig/v15'", "old: ''") + '; return { run };')(chromium, sets, fs, path, out, __dirname);
const BAD = /NaN|undefined|Infinity|-0(?![\d.])|\bnull\b|\[object/;
let fails = 0, n = 0;
(async () => {
  for (const name of ['rich', 'tradeLog', 'messy', 'allWin', 'single']) for (const w of [375, 1280]) {
    const { p, b, errs } = await run('new', sets[name].filter(Boolean).map(j => Object.assign({}, j)), w);
    for (const v of ['dashboard', 'monthly', 'statistik']) {
      await p.evaluate(x => switchView(x), v); await p.waitForTimeout(250);
      if (name === 'rich') { // with an active filter as well
        await p.evaluate(() => window.V165.setFilter('pair', 'XAUUSD')); await p.waitForTimeout(150);
      }
      const r = await p.evaluate((v2) => {
        const root = document.getElementById({ dashboard: 'view-dashboard', monthly: 'monthly-section', statistik: 'statistik-section' }[v2]);
        const t = root.innerText, bad = (t.match(/NaN|undefined|Infinity|-0(?![\d.])|\[object/g) || []);
        const small = [...root.querySelectorAll('#v165-dash *, #monthly-section *, #sp-root *, #ef-root *, #ps-root *')].filter(e => e.children.length === 0 && e.textContent.trim() && e.offsetParent && parseFloat(getComputedStyle(e).fontSize) < 13).map(e => e.textContent.trim().slice(0, 24) + ' @' + getComputedStyle(e).fontSize);
        return { bad, small: [...new Set(small)].slice(0, 5), ov: document.documentElement.scrollWidth - document.documentElement.clientWidth, len: t.length };
      }, v);
      n++;
      const bad = r.bad.length || r.ov > 1;
      if (bad) fails++;
      console.log((bad ? 'FAIL ' : 'PASS ') + `${name} ${w}px ${v}: bad=${JSON.stringify(r.bad)} overflow=${r.ov}px smallFonts=${JSON.stringify(r.small)}`);
      if (name === 'rich') { await p.evaluate(() => window.V165.clearFilters()); }
    }
    const real = errs.filter(e => !/hasPendingWrites/.test(e)); if (real.length) { fails++; console.log('FAIL errors ' + name + ' ' + w + ': ' + real.join('; ')); }
    await b.close();
  }
  console.log(fails ? `\n${fails} FAILED of ${n}` : `\nALL PASSED (${n} views)`); process.exit(fails ? 1 : 0);
})();
