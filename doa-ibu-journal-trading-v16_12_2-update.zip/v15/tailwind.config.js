/* ==========================================================================
   DOA IBU Trading Journal — Tailwind config (terhubung ke styles.css)
   --------------------------------------------------------------------------
   File ini bisa dipakai dua cara tanpa diubah:

   A) Tailwind CDN (cara yang dipakai index.html Anda sekarang)
      <script src="https://cdn.tailwindcss.com"></script>
      <script src="tailwind.config.js"></script>      <!-- ganti blok inline tailwind.config = {...} -->

   B) Tailwind build (npm / CLI) — file ini otomatis jadi module.exports.

   Format warna  rgb(var(--x) / <alpha-value>)  membuat modifier opacity
   tetap jalan:  bg-app-gold/10   text-trade-loss/80   border-app-border/50
   ========================================================================== */

const withAlpha = (variable) => `rgb(var(${variable}) / <alpha-value>)`;

const config = {
  // `dark:` aktif saat <html data-theme="dark">. (Tailwind ≥ 3.4.1)
  darkMode: ['selector', '[data-theme="dark"]'],

  // Hanya dipakai pada mode build; diabaikan oleh CDN.
  content: ['./index.html', './**/*.js'],

  theme: {
    extend: {
      colors: {
        /* ---- Permukaan, border, teks, emas → bg-app-surface, text-app-muted, ... ---- */
        app: {
          bg:              withAlpha('--app-bg'),
          surface:         withAlpha('--app-surface'),
          elevated:        withAlpha('--app-elevated'),

          border:          withAlpha('--app-border'),
          'border-strong': withAlpha('--app-border-strong'),

          text:            withAlpha('--app-text'),
          muted:           withAlpha('--app-text-muted'),
          subtle:          withAlpha('--app-text-subtle'),

          gold:            withAlpha('--app-gold'),        // bg-app-gold, border-app-gold
          'gold-hover':    withAlpha('--app-gold-hover'),  // hover:bg-app-gold-hover
          'gold-text':     withAlpha('--app-gold-text'),   // text-app-gold-text (emas sebagai teks)
          'on-gold':       withAlpha('--app-on-gold'),     // text-app-on-gold (teks di atas tombol emas)
        },

        /* ---- Profit / Loss → text-trade-profit, bg-trade-loss/10, ... ---- */
        trade: {
          profit: withAlpha('--trade-profit'),
          loss:   withAlpha('--trade-loss'),
        },

        /* ---- Palet lama dipertahankan agar markup index.html yang ada tidak rusak.
                (Bersifat statis: tidak ikut berubah saat ganti tema.) ---- */
        dark: {
          950: '#0a0a0b',
          900: '#111113',
          800: '#18181b',
          700: '#1f1f23',
          600: '#27272a',
          500: '#3f3f46',
        },
        gold: {
          400: '#e0b94a',
          500: '#d4af37',
          600: '#b8942a',
          700: '#9a7b1f',
        },
      },

      boxShadow: {
        'app-sm': 'var(--app-shadow-sm)',
        'app-md': 'var(--app-shadow-md)',
        'app-lg': 'var(--app-shadow-lg)',
      },

      ringColor: {
        DEFAULT: withAlpha('--app-gold'),
      },
    },
  },
};

/* Export universal: build (CommonJS) atau CDN (global `tailwind`). */
if (typeof module !== 'undefined' && module.exports) {
  module.exports = config;
} else if (typeof tailwind !== 'undefined') {
  tailwind.config = config;
}
